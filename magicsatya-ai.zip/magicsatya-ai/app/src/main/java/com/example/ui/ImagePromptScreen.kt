package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ImagePromptEngine
import com.example.ui.theme.ImagePromptColor
import com.example.ui.theme.MagicGold
import com.example.ui.theme.MagicPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImagePromptScreen(
    viewModel: MagicViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val language by viewModel.currentLanguage.collectAsState()
    val isHindi = language == AppLanguage.HINDI
    val isGenerating by viewModel.isGenerating.collectAsState()
    val isGeneratingImage by viewModel.isGeneratingImage.collectAsState()
    val imageResult by viewModel.lastImageResult.collectAsState()
    val lastGeneratedImage by viewModel.lastGeneratedImage.collectAsState()

    var userIdea by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf(ImagePromptEngine.styles[0]) }
    var selectedRatio by remember { mutableStateOf(ImagePromptEngine.aspectRatios[0]) }
    var selectedLighting by remember { mutableStateOf(ImagePromptEngine.lightingOptions[0]) }
    var selectedCamera by remember { mutableStateOf(ImagePromptEngine.cameraLenses[0]) }
    var isSaved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            MagicTopBar(
                title = if (isHindi) "इमेज प्रॉम्प्ट जनरेटर" else "AI Image Prompt Studio",
                subtitle = if (isHindi) "Midjourney, Flux व DALL-E के लिए" else "For Midjourney, Flux & DALL-E",
                onBackClick = onBackClick,
                currentLanguage = language,
                onLanguageToggle = { viewModel.toggleLanguage() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Info Pill
            item(key = "img_header_info_pill") {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ImagePromptColor.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎨",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isHindi) "हाई-क्वालिटी एआई इमेज प्रॉम्प्ट बनाएं" else "Master AI Image Prompt Builder",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = ImagePromptColor
                            )
                            Text(
                                text = if (isHindi) "कैमरा लेंस, लाइटिंग और 8K स्टाइल के साथ सटीक प्रॉम्प्ट" else "Cinematic lighting, camera parameters and Midjourney v6 ready",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Input: User Image Idea
            item(key = "img_input_idea") {
                Column {
                    Text(
                        text = if (isHindi) "आप क्या चित्र बनाना चाहते हैं? (Image Idea)" else "What image do you want to create?",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = userIdea,
                        onValueChange = { userIdea = it },
                        placeholder = {
                            Text(
                                text = if (isHindi) "उदा. प्राचीन बनारस घाट पर रात के समय नियॉन लाइट्स, 3D क्यूट गणेश जी..." else "e.g. Cyberpunk Varanasi Ghats at night with neon lights...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("image_prompt_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ImagePromptColor,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // Quick Beginner Suggestions
            item(key = "img_suggestions_section") {
                PromptSuggestionsSection(
                    title = "आर्ट आइडिया सुझाव (Art Ideas)",
                    hindiTitle = "1-क्लिक में चुनें",
                    suggestions = ImagePromptEngine.beginnerIdeas,
                    onSelectSuggestion = { userIdea = it }
                )
            }

            // Style Selector
            item(key = "img_style_selector") {
                Column {
                    Text(
                        text = if (isHindi) "कलात्मक शैली (Art Style)" else "Visual Art Style",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ImagePromptEngine.styles.forEach { style ->
                            val isSelected = selectedStyle == style
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) ImagePromptColor else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedStyle = style }
                                    .border(
                                        1.dp,
                                        if (isSelected) ImagePromptColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = style,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Aspect Ratio Selector
            item(key = "img_aspect_ratio_selector") {
                Column {
                    Text(
                        text = if (isHindi) "आकार / आस्पेक्ट रेशियो (Aspect Ratio)" else "Aspect Ratio",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ImagePromptEngine.aspectRatios.forEach { ratio ->
                            val isSelected = selectedRatio == ratio
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MagicPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedRatio = ratio }
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = ratio.split(" ")[0],
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Camera Lens & Lighting Modifiers
            item(key = "img_modifiers_row") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Lighting
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "लाइटिंग (Lighting)" else "Lighting",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val nextIndex = (ImagePromptEngine.lightingOptions.indexOf(selectedLighting) + 1) % ImagePromptEngine.lightingOptions.size
                                    selectedLighting = ImagePromptEngine.lightingOptions[nextIndex]
                                }
                                .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        ) {
                            Text(
                                text = "💡 ${selectedLighting.split(" ")[0]} ▾",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // Camera Lens
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "कैमरा लेंस (Lens)" else "Camera Lens",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val nextIndex = (ImagePromptEngine.cameraLenses.indexOf(selectedCamera) + 1) % ImagePromptEngine.cameraLenses.size
                                    selectedCamera = ImagePromptEngine.cameraLenses[nextIndex]
                                }
                                .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        ) {
                            Text(
                                text = "📷 ${selectedCamera.split(" ")[0]} ▾",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            // Generate Button
            item(key = "img_generate_button") {
                Button(
                    onClick = {
                        isSaved = false
                        viewModel.generateImagePrompt(
                            userIdea = userIdea,
                            style = selectedStyle,
                            aspectRatio = selectedRatio,
                            lighting = selectedLighting,
                            camera = selectedCamera
                        )
                    },
                    enabled = !isGenerating,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImagePromptColor
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("generate_image_prompt_button")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isHindi) "प्रॉम्प्ट तैयार हो रहा है..." else "Formulating Master Prompt...",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Generate",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "✨ मास्टर इमेज प्रॉम्प्ट बनाएं (Generate Prompt)" else "✨ Generate Master Image Prompt",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Generated Image Prompt Card
            if (imageResult != null) {
                item(key = "img_result_card") {
                    val result = imageResult!!
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(20.dp)
                            )
                            .testTag("image_result_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Style and tags
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = ImagePromptColor.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "🎨 ${result.styleUsed.take(20)}...",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = ImagePromptColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = result.midjourneyFlags.split(" ")[0],
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MagicGold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "🌟 Master Prompt (कॉपी करने के लिए तैयार):",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = result.masterPrompt,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 13.sp,
                                        lineHeight = 19.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Hindi Explanation
                            Text(
                                text = result.hindiSummary,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Negative Prompt box
                            Text(
                                text = "🚫 Negative Prompt:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFFF87171)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = result.negativePrompt,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // REAL AI IMAGE GENERATION ACTION BUTTON
                            Button(
                                onClick = {
                                    viewModel.generateRealImageForPrompt(
                                        prompt = result.masterPrompt,
                                        style = result.styleUsed,
                                        aspectRatio = result.aspectRatio
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ImagePromptColor
                                ),
                                enabled = !isGeneratingImage,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("generate_real_image_from_prompt_button")
                            ) {
                                if (isGeneratingImage) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isHindi) "✨ 8K AI छवि तैयार हो रही है..." else "✨ Rendering 8K AI Image...",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Generate Real Image",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isHindi) "🎨 इस प्रॉम्प्ट से असली छवि बनाएं (Generate Image)" else "🎨 Generate Real AI Image",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action Toolbar
                            ResultActionToolbar(
                                contentToCopy = "${result.masterPrompt}\n\n[Negative Prompt]: ${result.negativePrompt}\n[Parameters]: ${result.midjourneyFlags}",
                                onPlayAudio = null,
                                isSaved = isSaved,
                                onSaveToVault = {
                                    viewModel.saveItem(
                                        category = "IMAGE",
                                        title = result.title,
                                        hindiTitle = result.hindiSummary,
                                        promptInput = userIdea,
                                        generatedContent = result.masterPrompt,
                                        secondaryContent = "Negative: ${result.negativePrompt} | ${result.midjourneyFlags}",
                                        styleOrGenre = selectedStyle,
                                        language = "English / Prompt"
                                    )
                                    isSaved = true
                                },
                                isHindi = isHindi
                            )
                        }
                    }
                }
            }

            // Real Generated Image Card
            if (lastGeneratedImage != null) {
                item(key = "real_generated_image_card_item") {
                    val genImg = lastGeneratedImage!!
                    RealGeneratedImageCard(
                        imageData = genImg,
                        isHindi = isHindi,
                        onDownload = {
                            viewModel.downloadImageToGallery(genImg)
                        },
                        onRegenerate = {
                            if (imageResult != null) {
                                viewModel.generateRealImageForPrompt(
                                    prompt = imageResult!!.masterPrompt,
                                    style = imageResult!!.styleUsed,
                                    aspectRatio = imageResult!!.aspectRatio
                                )
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
