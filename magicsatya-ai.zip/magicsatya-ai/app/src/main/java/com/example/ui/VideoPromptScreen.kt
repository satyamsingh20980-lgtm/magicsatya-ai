package com.example.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.VideoPromptEngine
import com.example.ui.theme.MagicGold
import com.example.ui.theme.MagicPrimary
import com.example.ui.theme.VideoPromptColor

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoPromptScreen(
    viewModel: MagicViewModel,
    onBackClick: () -> Unit
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isHindi = language == AppLanguage.HINDI
    val isGenerating by viewModel.isGenerating.collectAsState()
    val isGeneratingVideo by viewModel.isGeneratingVideo.collectAsState()
    val videoResult by viewModel.lastVideoResult.collectAsState()
    val generatedVideo by viewModel.lastGeneratedVideo.collectAsState()

    var sceneIdea by remember { mutableStateOf("") }
    var selectedModel by remember { mutableStateOf(VideoPromptEngine.aiVideoModels[0]) }
    var selectedMotion by remember { mutableStateOf(VideoPromptEngine.cameraMotions[0]) }
    var selectedStyle by remember { mutableStateOf(VideoPromptEngine.videoStyles[0]) }
    var isSaved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            MagicTopBar(
                title = if (isHindi) "वीडियो प्रॉम्प्ट जनरेटर" else "AI Video Prompt Studio",
                subtitle = if (isHindi) "Sora, Runway Gen-3 व Kling AI के लिए" else "For Sora, Runway & Kling AI",
                onBackClick = onBackClick,
                currentLanguage = language,
                onLanguageToggle = { viewModel.toggleLanguage() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Info Pill
            item(key = "vid_header_info_pill") {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = VideoPromptColor.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎬",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isHindi) "सिनेमैटिक एआई वीडियो प्रॉम्प्ट बनाएं" else "Cinematic AI Video Prompt Generator",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = VideoPromptColor
                            )
                            Text(
                                text = if (isHindi) "कैमरा मूवमेंट (ड्रोन, पैन, एफपीवी) और भौतिकी गति के साथ" else "Camera physics, drone paths and prompt formulas for Gen-3 & Sora",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Input: Scene description
            item(key = "vid_input_scene") {
                Column {
                    Text(
                        text = if (isHindi) "वीडियो का दृश्य / सीन (Video Scene Concept)" else "Video Scene Idea",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = sceneIdea,
                        onValueChange = { sceneIdea = it },
                        placeholder = {
                            Text(
                                text = if (isHindi) "उदा. भविष्य की मुंबई में उड़ती टैक्सियां जो बारिश में चमक रही हैं..." else "e.g. A golden eagle flying over Himalayan snowy peaks, 4K drone...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("video_scene_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VideoPromptColor,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // Beginner video prompt suggestions
            item(key = "vid_suggestions_section") {
                PromptSuggestionsSection(
                    title = "वीडियो आइडिया सुझाव (Video Ideas)",
                    hindiTitle = "1-क्लिक में चुनें",
                    suggestions = VideoPromptEngine.beginnerVideoIdeas,
                    onSelectSuggestion = { sceneIdea = it }
                )
            }

            // Target AI Video Model Selector
            item(key = "vid_model_selector") {
                Column {
                    Text(
                        text = if (isHindi) "टारगेट एआई मॉडल (Target AI Video Model)" else "AI Video Model Preset",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoPromptEngine.aiVideoModels.forEach { model ->
                            val isSelected = selectedModel == model
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MagicPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedModel = model }
                                    .border(
                                        1.dp,
                                        if (isSelected) MagicPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = model,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Camera Motion Selector
            item(key = "vid_motion_selector") {
                Column {
                    Text(
                        text = if (isHindi) "कैमरा मूवमेंट / मोशन (Camera Movement)" else "Camera Motion Dynamics",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoPromptEngine.cameraMotions.forEach { motion ->
                            val isSelected = selectedMotion == motion
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) VideoPromptColor else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedMotion = motion }
                                    .border(
                                        1.dp,
                                        if (isSelected) VideoPromptColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = motion,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Video Style Selector
            item(key = "vid_style_selector") {
                Column {
                    Text(
                        text = if (isHindi) "वीडियो स्टाइल (Visual Style)" else "Visual Style",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoPromptEngine.videoStyles.forEach { style ->
                            val isSelected = selectedStyle == style
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MagicGold else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedStyle = style }
                                    .border(
                                        1.dp,
                                        if (isSelected) MagicGold else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = style,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Generate Button
            item(key = "vid_generate_button") {
                Button(
                    onClick = {
                        isSaved = false
                        viewModel.generateVideoPrompt(
                            sceneIdea = sceneIdea,
                            targetModel = selectedModel,
                            cameraMotion = selectedMotion,
                            style = selectedStyle,
                            duration = "5s",
                            fps = "60 FPS Cinematic",
                            onComplete = {
                                // Automatically trigger real video generation with the new prompt
                                val currentPrompt = viewModel.lastVideoResult.value?.masterPrompt ?: sceneIdea
                                viewModel.generateRealVideoForPrompt(
                                    prompt = currentPrompt,
                                    style = selectedStyle,
                                    cameraMotion = selectedMotion,
                                    modelName = selectedModel,
                                    durationSeconds = 4
                                )
                            }
                        )
                    },
                    enabled = !isGenerating && !isGeneratingVideo,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VideoPromptColor
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("generate_video_prompt_button")
                ) {
                    if (isGenerating || isGeneratingVideo) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isGenerating) {
                                if (isHindi) "वीडियो प्रॉम्प्ट बन रहा है..." else "Directing Video Prompt..."
                            } else {
                                if (isHindi) "🎬 AI वीडियो (MP4) तैयार हो रहा है..." else "🎬 Generating AI Video (MP4)..."
                            },
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Generate",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "✨ प्रॉम्प्ट व AI वीडियो बनाएं (Generate Video)" else "✨ Generate Prompt & AI Video",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Video Prompt Result Card
            if (videoResult != null) {
                item(key = "vid_result_card") {
                    val result = videoResult!!
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(20.dp)
                            )
                            .testTag("video_result_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Top Model Badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = VideoPromptColor.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "🎬 ${selectedModel.split(" ")[0]}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = VideoPromptColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = "📹 ${selectedMotion.split(" ")[0]}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "🎥 Master Video Generation Prompt:",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = result.masterPrompt,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 13.sp,
                                        lineHeight = 19.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Camera directive details
                            Text(
                                text = "🧭 Camera Dynamics & Path:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = VideoPromptColor
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = result.cameraMovementPrompt,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Motion and physics
                            Text(
                                text = "⚡ Motion Coherence & Physics:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MagicGold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = result.motionAndPhysics,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Toolbar
                            ResultActionToolbar(
                                contentToCopy = result.masterPrompt,
                                onPlayAudio = null,
                                isSaved = isSaved,
                                onSaveToVault = {
                                    viewModel.saveItem(
                                        category = "VIDEO",
                                        title = result.title,
                                        hindiTitle = "वीडियो प्रॉम्प्ट: ${sceneIdea.take(25)}",
                                        promptInput = sceneIdea,
                                        generatedContent = result.masterPrompt,
                                        secondaryContent = result.cameraMovementPrompt,
                                        styleOrGenre = selectedModel,
                                        language = "English / Video AI"
                                    )
                                    isSaved = true
                                },
                                isHindi = isHindi
                            )
                        }
                    }
                }
            }

            // Video Generation In-Progress Indicator Card
            if (isGeneratingVideo) {
                item(key = "vid_generating_progress_card") {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = VideoPromptColor.copy(alpha = 0.08f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, VideoPromptColor.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                color = VideoPromptColor,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (isHindi) "🎬 AI वीडियो मॉडल कॉल हो रहा है..." else "🎬 Calling AI Video Model API...",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = VideoPromptColor
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isHindi) "HuggingFace/Fal.ai वीडियो फ्रेम जनरेट व MP4 स्ट्रीम हो रही है..." else "Synthesizing dynamic camera motion & 60 FPS MP4 stream...",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Rendered Real MP4 Video Player Card
            if (generatedVideo != null) {
                item(key = "vid_player_card_${generatedVideo!!.id}") {
                    val videoData = generatedVideo!!
                    RealGeneratedVideoPlayerCard(
                        videoData = videoData,
                        isHindi = isHindi,
                        onDownload = {
                            viewModel.downloadVideoToGallery(videoData)
                        },
                        onRegenerate = {
                            val currentPrompt = videoResult?.masterPrompt ?: sceneIdea
                            viewModel.generateRealVideoForPrompt(
                                prompt = currentPrompt,
                                style = selectedStyle,
                                cameraMotion = selectedMotion,
                                modelName = selectedModel,
                                durationSeconds = 4
                            )
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
