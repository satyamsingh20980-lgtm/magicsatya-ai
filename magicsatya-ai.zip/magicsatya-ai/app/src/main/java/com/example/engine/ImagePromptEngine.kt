package com.example.engine

data class ImagePromptResult(
    val title: String,
    val masterPrompt: String,
    val hindiSummary: String,
    val negativePrompt: String,
    val midjourneyFlags: String,
    val styleUsed: String,
    val aspectRatio: String,
    val lightingAndCamera: String
)

object ImagePromptEngine {

    val styles = listOf(
        "Photorealistic 8K Cinematic (अति-यथार्थवादी 8K)",
        "3D Disney/Pixar Cute Animation (3D पिक्सार एनीमेशन)",
        "Cyberpunk Neon Futuristic (साइबरपंक नियॉन)",
        "Indian Royal & Cultural / Madhubani (शाही भारतीय कला)",
        "Anime & Studio Ghibli Aesthetic (एनीमे गिबली स्टाइल)",
        "Oil Painting & Renaissance Masterpiece (ऑयल पेंटिंग कला)",
        "Dark Fantasy & Mystical Unreal Engine 5 (डार्क फैंटेसी)"
    )

    val aspectRatios = listOf(
        "16:9 (Landscape / YouTube)",
        "9:16 (Vertical / Reels & Shorts)",
        "1:1 (Square / Instagram)",
        "4:5 (Portrait Feed)"
    )

    val lightingOptions = listOf(
        "Golden Hour Warm Sunlight (सुनहरी धूप)",
        "Cyberpunk Neon Glow (नियॉन लाइट)",
        "Dramatic Studio Volumetric Lighting (स्टूडियो लाइटिंग)",
        "Ethereal Bioluminescent Night (चमकती रात)",
        "Cinematic Moody Film Lighting (सिनेमैटिक शेड्स)"
    )

    val cameraLenses = listOf(
        "85mm f/1.4 Portrait Bokeh",
        "Wide-Angle 16mm Epic Drone Shot",
        "Macro Close-Up Extreme Detail",
        "Cinematic 35mm Anamorphic Lens",
        "Hasselblad Medium Format 100MP"
    )

    val beginnerIdeas = listOf(
        "प्राचीन बनारस घाट पर रात के समय तैरते हुए नियॉन दीये और लेजर लाइट्स",
        "एक प्यारा 3D क्यूट बेबी गणेश जी जो बादलों के झूले पर मुस्कुरा रहे हैं",
        "अंतरिक्ष में भारतीय अंतरिक्ष यात्री जो सोने का ताजमहल तैरता हुआ देख रहा है",
        "कमल के फूल पर बारिश की चमकदार बूंदें, मैक्रो फोटोग्राफी 8K",
        "हिमालय की बर्फीली चोटी पर ध्यान मग्न एक योगी जिसके चारों ओर दिव्य नीली ऊर्जा है"
    )

    fun generatePrompt(
        userIdea: String,
        style: String,
        aspectRatio: String,
        lighting: String,
        camera: String,
        includeHindiContext: Boolean = true
    ): ImagePromptResult {
        val concept = if (userIdea.isNotBlank()) userIdea.trim() else "Mystical radiant guardian spirit in a sacred glowing temple"
        
        val styleTag = when {
            style.contains("Pixar", ignoreCase = true) -> "3D stylized character render, Pixar and Disney animation studio quality, ultra cute charming expressive facial expression, subsurface scattering, soft ambient lighting, smooth render, vibrant pastel color grading"
            style.contains("Cyberpunk", ignoreCase = true) -> "Cyberpunk aesthetic, hyper-futuristic neon drenched reflections, holographic interfaces, wet asphalt pavement, volumetric atmospheric fog, high-tech intricate mechanical details, octane render"
            style.contains("Indian", ignoreCase = true) -> "Majestic Indian heritage aesthetics, royal intricate golden embroidery, ornate palace carvings, rich traditional colors, silk textiles, cinematic cultural grandeur, regal aura"
            style.contains("Anime", ignoreCase = true) -> "Studio Ghibli and Makoto Shinkai aesthetic, hand-drawn anime key visual, lush painterly cloudscapes, sparkling light particles, emotionally resonant composition, masterpiece 4k"
            style.contains("Oil", ignoreCase = true) -> "Classic oil on canvas masterpiece, heavy brushwork texture, dramatic chiaroscuro Rembrandt lighting, rich museum quality palette, classical fine art"
            style.contains("Dark Fantasy", ignoreCase = true) -> "Dark fantasy Unreal Engine 5 render, ancient glowing runes, gothic monoliths, ominous ethereal mist, epic scale, ray tracing, dark fantasy concept art"
            else -> "Hyper-realistic award winning photograph, 8k resolution, photorealistic skin textures, incredible micro-details, ultra-sharp focus, cinematic color palette, Hasselblad color science"
        }

        val arFlag = when {
            aspectRatio.contains("9:16") -> "--ar 9:16"
            aspectRatio.contains("16:9") -> "--ar 16:9"
            aspectRatio.contains("4:5") -> "--ar 4:5"
            else -> "--ar 1:1"
        }

        val masterPrompt = "$concept, $styleTag, shot with $camera, $lighting, hyper-detailed, masterpiece, highly intricate, 8k resolution, beautiful composition, trending on Artstation"

        val negativePrompt = "blurry, low quality, distorted anatomy, extra fingers, text, watermark, bad hands, mutated limbs, cropped, oversaturated, lowres, artifacts, deformed, noisy"

        val midjourneyFlags = "$arFlag --v 6.1 --stylize 300 --quality 2"

        val hindiSummary = "💡 यह प्रॉम्प्ट \"$concept\" के लिए $style स्टाइल में 8K अल्ट्रा-डिटेल इमेज जनरेट करने के लिए ऑप्टिमाइज़ किया गया है।"

        return ImagePromptResult(
            title = "AI Art: ${concept.take(30)}...",
            masterPrompt = masterPrompt,
            hindiSummary = hindiSummary,
            negativePrompt = negativePrompt,
            midjourneyFlags = midjourneyFlags,
            styleUsed = style,
            aspectRatio = aspectRatio,
            lightingAndCamera = "$camera | $lighting"
        )
    }
}
