package com.example.engine

data class VoiceScriptResult(
    val title: String,
    val hindiTitle: String,
    val scriptType: String,
    val tone: String,
    val fullScriptHindi: String,
    val fullScriptHinglish: String,
    val hookSegment: String,
    val bodySegment: String,
    val ctaSegment: String,
    val estimatedDurationSeconds: Int,
    val wordCount: Int,
    val teleprompterLines: List<String>
)

object VoiceScriptEngine {

    val scriptCategories = listOf(
        "Viral Short / Instagram Reel (15-30s)",
        "YouTube Video Hook & Intro (30-60s)",
        "Motivational High-Energy Speech (जोशीला भाषण)",
        "Spiritual & Mythological (धार्मिक व पौराणिक)",
        "Product & Brand Commercial Ad (आकर्षक विज्ञापन)",
        "Podcast Storytelling & Deep Talk (पॉडकास्ट विचार)"
    )

    val tones = listOf(
        "High Energy & Hooking (जोशीला / वायरल)",
        "Warm, Calming & Emotional (शांत व दिल को छूने वाला)",
        "Deep Professional Storyteller (गंभीर कथावाचक)",
        "Fast-Paced Casual & Friendly (दोस्ताना व तेज)"
    )

    val beginnerTopics = listOf(
        "रामायण की 3 सबसे बड़ी सीख जो आपकी जिंदगी बदल देंगी",
        "भगवद्गीता का वह एक श्लोक जो तनाव को 10 सेकंड में खत्म कर देता है",
        "3 आदतें जो 30 दिनों में आपका दिमाग 10 गुना तेज कर देंगी",
        "अगर आप सुबह 5 बजे उठना चाहते हैं तो यह 1 गलती कभी मत करना",
        "AI के आने के बाद ये 5 नौकरियां सबसे ज्यादा पैसा कमाएंगी"
    )

    suspend fun generateScriptAsync(
        topic: String,
        category: String,
        tone: String
    ): VoiceScriptResult {
        val topicClean = if (topic.isNotBlank()) topic.trim() else "रामायण की अमर सीख"

        val systemPrompt = """
            You are MagicSatya AI, a world-class viral YouTube Shorts & Reels scriptwriter in Hindi.
            Write a high-converting, deeply engaging voice-over script based strictly on the user's exact topic.
            Follow these rules:
            1. If the topic is about Ramayana, Mahabharata, or spiritual/historical topics, use authentic facts, real characters (Lord Ram, Sita, Lakshman, Hanuman, Ravana, Krishna, etc.) and deep wisdom.
            2. Hook: 3-5 seconds powerful opening question or statement.
            3. Body: 2-3 concise, impactful value beats with pacing tags like [Pause], [High Energy].
            4. CTA: Engaging closing call-to-action.
            5. Provide pure Hindi and Hinglish script versions.
        """.trimIndent()

        val userPrompt = "Topic: $topicClean\nCategory: $category\nTone: $tone"
        val aiResult = GeminiService.generateContent(systemPrompt, userPrompt)

        if (aiResult != null && aiResult.isNotBlank()) {
            val words = aiResult.split("\\s+".toRegex()).size
            val estDuration = (words / 2.5).toInt().coerceIn(20, 90)
            return VoiceScriptResult(
                title = "वॉयस-ओवर: ${topicClean.take(30)}",
                hindiTitle = topicClean,
                scriptType = category,
                tone = tone,
                fullScriptHindi = aiResult,
                fullScriptHinglish = aiResult,
                hookSegment = "3-Second Viral Hook",
                bodySegment = aiResult,
                ctaSegment = "Like & Share",
                estimatedDurationSeconds = estDuration,
                wordCount = words,
                teleprompterLines = aiResult.lines().filter { it.isNotBlank() }
            )
        }

        return generateScript(topicClean, category, tone)
    }

    fun generateScript(
        topic: String,
        category: String,
        tone: String,
        includeHinglish: Boolean = true
    ): VoiceScriptResult {
        val topicClean = if (topic.isNotBlank()) topic.trim() else "रामायण की सबसे बड़ी सीख"
        val lower = topicClean.lowercase()

        // 1. RAMAYANA VOICE SCRIPT
        if (lower.contains("राम") || lower.contains("ramayan") || lower.contains("रामायण") ||
            lower.contains("सीता") || lower.contains("हनुमान") || lower.contains("रावण") ||
            lower.contains("अयोध्या") || lower.contains("rama")) {
            return generateRamayanaScript(topicClean, category, tone)
        }

        // 2. MAHABHARATA / GITA SCRIPT
        if (lower.contains("महाभारत") || lower.contains("mahabharat") || lower.contains("कृष्ण") ||
            lower.contains("गीता") || lower.contains("gita") || lower.contains("अर्जुन")) {
            return generateGitaScript(topicClean, category, tone)
        }

        // 3. MOTIVATION / HABITS / SUCCESS
        if (lower.contains("आदत") || lower.contains("habit") || lower.contains("सफलता") ||
            lower.contains("success") || lower.contains("दिमाग") || lower.contains("5 am") ||
            lower.contains("सुबह") || lower.contains("मोटिवेशन")) {
            return generateHabitsScript(topicClean, category, tone)
        }

        // 4. TECH / AI / JOBS
        if (lower.contains("ai") || lower.contains("एआई") || lower.contains("यूट्यूब") ||
            lower.contains("पैसा") || lower.contains("नौकरी") || lower.contains("tech")) {
            return generateTechScript(topicClean, category, tone)
        }

        // 5. DYNAMIC GENERAL SCRIPT FOR USER TOPIC
        return generateDynamicScript(topicClean, category, tone)
    }

    private fun generateRamayanaScript(topic: String, category: String, tone: String): VoiceScriptResult {
        val hookHindi = "⚡ [3 सेकंड का वायरल हुक] क्या आप जानते हैं कि रामायण की वह कौन सी एक सीख है जो किसी भी इंसान को अजेय बना सकती है?"
        val hookHinglish = "⚡ [3s Viral Hook] Kya aap jaante hain Ramayan ki wo ek seekh jo kisi bhi insaan ko invincible bana sakti hai?"

        val bodyHindi = """
📌 **1. मर्यादा और वचन की शक्ति (Power of Principles)**
[गंभीर आवाज में] प्रभु श्री राम ने पिता के एक वचन के लिए बिना एक पल सोचे 14 वर्ष का वनवास स्वीकार किया। सुख-सुविधाएं क्षणिक होती हैं, लेकिन आपके सिद्धांत अमर होते हैं।

📌 **2. हनुमान जी जैसी निष्ठा और विश्वास (Dedication & Faith)**
[उत्साह के साथ] जब मन में समर्पण हो, तो पत्थरों पर भी नाम लिखकर समुद्र पार किया जा सकता है। असंभव को संभव बनाने की चाबी अटूट विश्वास है।

📌 **3. अहंकार का निश्चित पतन (Destruction of Ego)**
[दृढ़ स्वर] रावण के पास अपार शक्ति, धन और ज्ञान था, लेकिन अहंकार ने उसका सर्वनाश कर दिया। ज्ञान तभी शोभा देता है जब उसमें विनम्रता हो।
        """.trimIndent()

        val bodyHinglish = """
📌 **1. Power of Principles**
[Deep tone] Prabhu Shri Ram ne pita ke ek vachan ke liye 14 saal ka vanvaas haste-haste accept kiya. Comforts temporary hain, principles permanent!

📌 **2. Faith & Dedication**
[With energy] Hanuman Ji ki tarah dedication ho toh pathar bhi samundar par tairte hain. Unwavering belief har impossible ko possible bana deta hai.

📌 **3. Ego leads to Fall**
[Firm tone] Ravan ke paas knowledge, wealth aur power sab tha, par arrogance ne sab destroy kar diya.
        """.trimIndent()

        val ctaHindi = "🚀 [कॉल टू एक्शन] अगर प्रभु श्री राम की यह मर्यादा आपके दिल को छू गई हो, तो कमेंट में 'जय श्री राम' लिखें और इस वीडियो को अपने परिवार के साथ जरूर शेयर करें!"
        val ctaHinglish = "🚀 [Call To Action] Agar Ramayan ki yeh seekh aapke dil ko touch hui ho, toh comment mein 'Jai Shree Ram' likhein aur video ko abhi SHARE karein!"

        val fullHindi = "$hookHindi\n\n$bodyHindi\n\n$ctaHindi"
        val fullHinglish = "$hookHinglish\n\n$bodyHinglish\n\n$ctaHinglish"
        val words = fullHindi.split("\\s+".toRegex()).size

        return VoiceScriptResult(
            title = "वॉयस-ओवर: रामायण की अमर सीख",
            hindiTitle = topic,
            scriptType = category,
            tone = tone,
            fullScriptHindi = fullHindi,
            fullScriptHinglish = fullHinglish,
            hookSegment = hookHindi,
            bodySegment = bodyHindi,
            ctaSegment = ctaHindi,
            estimatedDurationSeconds = (words / 2.5).toInt().coerceIn(30, 75),
            wordCount = words,
            teleprompterLines = fullHindi.split("\n").filter { it.isNotBlank() }
        )
    }

    private fun generateGitaScript(topic: String, category: String, tone: String): VoiceScriptResult {
        val hookHindi = "🔥 [गहरी आवाज] जब जिंदगी में चारों तरफ अंधकार दिखे और रास्ते बंद हो जाएं, तो कुरुक्षेत्र में श्री कृष्ण द्वारा दिया गया यह एक उपदेश याद रखना!"
        val hookHinglish = "🔥 [Deep Hook] Jab life mein sab raste band lagne lagein, tab Kurukshetra mein Shri Krishna ka yeh ek updesh yaad rakhna!"

        val bodyHindi = """
📌 **1. केवल कर्म पर अधिकार (Focus on Action, Not Outcome)**
[शांत भाव से] 'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन'—भविष्य की चिंता छोड़िए और वर्तमान में जो काम आपके हाथ में है, उसे पूरी जान लगाकर कीजिए।

📌 **2. मन को वश में करना (Mastering the Mind)**
[उत्साह से] अर्जुन ने जब कहा कि मन हवा की तरह चंचल है, तो श्री कृष्ण ने कहा—'अभ्यास और वैराग्य' से चंचल मन भी आपका सबसे बड़ा मित्र बन जाता है।

📌 **3. धर्म और सत्य का साथ (Stand for Righteousness)**
[दृढ़ स्वर] जब आप सच्चाई के रास्ते पर होते हैं, तो पूरी सृष्टि आपको विजयी बनाने में लग जाती है।
        """.trimIndent()

        val bodyHinglish = """
📌 **1. Action Over Anxiety**
[Calm tone] 'Karmanye Vadhikaraste'—future ki anxiety chhodiye aur present action par 100% focus kijiye.

📌 **2. Mind Control**
[Energetic] Consistent practice aur detachment se unmanageable mind bhi aapka best friend ban jaata hai.

📌 **3. Truth always wins**
[Firm tone] Jab aap right path par hote hain, toh destiny aapka sath deti hai.
        """.trimIndent()

        val ctaHindi = "🚀 [कॉल टू एक्शन] अगर गीता के इस ज्ञान ने आपको नई दिशा दी हो, तो वीडियो को लाइक करें और इसे सेव कर लें ताकि जब भी मन भटके, आप इसे दोबारा सुन सकें!"
        val ctaHinglish = "🚀 [Call To Action] Agar Gita ke gyan ne aapko inspiration di ho, toh video ko LIKE karein aur SAVE kar lijiye!"

        val fullHindi = "$hookHindi\n\n$bodyHindi\n\n$ctaHindi"
        val fullHinglish = "$hookHinglish\n\n$bodyHinglish\n\n$ctaHinglish"
        val words = fullHindi.split("\\s+".toRegex()).size

        return VoiceScriptResult(
            title = "वॉयस-ओवर: भगवद्गीता का दिव्य ज्ञान",
            hindiTitle = topic,
            scriptType = category,
            tone = tone,
            fullScriptHindi = fullHindi,
            fullScriptHinglish = fullHinglish,
            hookSegment = hookHindi,
            bodySegment = bodyHindi,
            ctaSegment = ctaHindi,
            estimatedDurationSeconds = (words / 2.5).toInt().coerceIn(30, 75),
            wordCount = words,
            teleprompterLines = fullHindi.split("\n").filter { it.isNotBlank() }
        )
    }

    private fun generateHabitsScript(topic: String, category: String, tone: String): VoiceScriptResult {
        val hookHindi = "⚡ [जोशीला हुक] रुकिए! अगर आप अगले 6 महीनों में अपनी जिंदगी 180 डिग्री बदलना चाहते हैं, तो इन 3 गोल्डन रूल्स को कभी मत भूलना!"
        val hookHinglish = "⚡ [High Energy Hook] Stop scrolling! Agar agle 6 months mein apni life transform karni hai, toh yeh 3 golden rules follow karo!"

        val bodyHindi = """
📌 **1. 1% दैनिक सुधार (The 1% Daily Compound Effect)**
[उत्साह से] हर रोज सिर्फ 1% बेहतर बनिए। साल के अंत में आप 37 गुना आगे होंगे। छोटी आदतें ही बड़ा चमत्कार करती हैं।

📌 **2. स्क्रीन टाइम पर नियंत्रण (Control Digital Distraction)**
[गंभीर स्वर] सुबह उठते ही पहले 60 मिनट फोन मत छुइए। उस समय को अपने मन, व्यायाम और दिन की योजना में लगाइए।

📌 **3. बिना रुके निरंतरता (Consistency Beats Talent)**
[दृढ़ता से] टैलेंट हार सकता है, लेकिन हर दिन बिना नागा मेहनत करने वाला इंसान कभी नहीं हारता।
        """.trimIndent()

        val bodyHinglish = """
📌 **1. 1% Daily Compounding**
[With enthusiasm] Daily sirf 1% better baniye. 1 saal mein aap 37x aage honge!

📌 **2. Digital Detox First Hour**
[Deep tone] Morning ke pehle 60 minutes smartphone mat check kijiye. Exercise aur planning par focus karein.

📌 **3. Consistency Beats Talent**
[Firm tone] Motivation aati jaati rehti hai, par daily discipline aapko champion banata hai.
        """.trimIndent()

        val ctaHindi = "🚀 [कॉल टू एक्शन] क्या आप आज से यह चुनौती लेने के लिए तैयार हैं? कमेंट में 'I AM READY' लिखें और अपने बेस्ट फ्रेंड के साथ शेयर करें!"
        val ctaHinglish = "🚀 [Call To Action] Kya aap ready hain? Comment mein 'I AM READY' likhein aur friend ke sath share karein!"

        val fullHindi = "$hookHindi\n\n$bodyHindi\n\n$ctaHindi"
        val fullHinglish = "$hookHinglish\n\n$bodyHinglish\n\n$ctaHinglish"
        val words = fullHindi.split("\\s+".toRegex()).size

        return VoiceScriptResult(
            title = "वॉयस-ओवर: सफलता और आदतें",
            hindiTitle = topic,
            scriptType = category,
            tone = tone,
            fullScriptHindi = fullHindi,
            fullScriptHinglish = fullHinglish,
            hookSegment = hookHindi,
            bodySegment = bodyHindi,
            ctaSegment = ctaHindi,
            estimatedDurationSeconds = (words / 2.5).toInt().coerceIn(30, 75),
            wordCount = words,
            teleprompterLines = fullHindi.split("\n").filter { it.isNotBlank() }
        )
    }

    private fun generateTechScript(topic: String, category: String, tone: String): VoiceScriptResult {
        val hookHindi = "🚀 [आकर्षक हुक] क्या आप जानते हैं कि AI के इस दौर में वो कौन सी स्किल है जो आपको कभी बेरोजगार नहीं होने देगी?"
        val hookHinglish = "🚀 [Hook] Kya aap jaante hain AI ke is era mein sabse high-demand superpower kya hai?"

        val bodyHindi = """
📌 **1. AI टूल्स में निपुणता (Mastering AI Tools)**
[उत्साह से] AI आपकी नौकरी नहीं लेगा, लेकिन AI इस्तेमाल करने वाला इंसान आपकी जगह जरूर ले सकता है। इसलिए टूल्स को अपना दोस्त बनाइए।

📌 **2. रचनात्मक सोच और प्रॉम्प्ट इंजीनियरिंग (Prompt Mastery)**
[गहराई से] सही सवाल पूछना और सटीक प्रॉम्प्ट लिखना ही भविष्य का सबसे बड़ा हुनर है।

📌 **3. निरंतर नया सीखने की भूख (Continuous Adaptation)**
[दृढ़ स्वर] जो तेजी से सीखता और बदलता है, वही डिजिटल युग में सबसे आगे निकलता है।
        """.trimIndent()

        val bodyHinglish = """
📌 **1. Use AI as Superpower**
[Energetic] AI tool seekhiye aur apna output 10x badhaiye.

📌 **2. Prompt Mastery & Creativity**
[Deep tone] Sahi sawal poochna aur clear prompt dena hi future ki top skill hai.

📌 **3. Continuous Learning**
[Firm tone] New technologies ko embrace kijiye aur ahead of curve rahiye!
        """.trimIndent()

        val ctaHindi = "🚀 [कॉल टू एक्शन] अगर आप भी टेक और AI में आगे रहना चाहते हैं, तो अभी फॉलो करें और अपने ग्रुप में शेयर करें!"
        val ctaHinglish = "🚀 [Call To Action] Agar aap tech mein top par rehna chahte hain, toh abhi SHARE & FOLLOW karein!"

        val fullHindi = "$hookHindi\n\n$bodyHindi\n\n$ctaHindi"
        val fullHinglish = "$hookHinglish\n\n$bodyHinglish\n\n$ctaHinglish"
        val words = fullHindi.split("\\s+".toRegex()).size

        return VoiceScriptResult(
            title = "वॉयस-ओवर: AI और भविष्य की स्किल्स",
            hindiTitle = topic,
            scriptType = category,
            tone = tone,
            fullScriptHindi = fullHindi,
            fullScriptHinglish = fullHinglish,
            hookSegment = hookHindi,
            bodySegment = bodyHindi,
            ctaSegment = ctaHindi,
            estimatedDurationSeconds = (words / 2.5).toInt().coerceIn(30, 75),
            wordCount = words,
            teleprompterLines = fullHindi.split("\n").filter { it.isNotBlank() }
        )
    }

    private fun generateDynamicScript(topic: String, category: String, tone: String): VoiceScriptResult {
        val hookHindi = "⚡ [3 सेकंड का वायरल हुक] क्या आपने कभी सोचा है कि $topic के पीछे का असली सच क्या है? अगले 45 सेकंड में आपको पूरी सच्चाई पता चलने वाली है!"
        val hookHinglish = "⚡ [3s Viral Hook] Kya aapne socha hai $topic ke peeche ka real secret kya hai? Next 45 seconds will give you the answer!"

        val bodyHindi = """
📌 **1. मुख्य मुद्दा और पहली नजर (The Core Insight)**
[गहराई से बोलें] जब हम '$topic' की बात करते हैं, तो सबसे पहले हमें जमीनी हकीकत को समझना होगा। आधी अधूरी जानकारी हमेशा नुकसानदेह होती है।

📌 **2. अनुभव और असली सीख (Key Lesson)**
[उत्साह के साथ] सही दिशा और स्पष्ट सोच के साथ जब कोई कदम उठाया जाता है, तो परिणाम हमेशा चौंकाने वाले होते हैं।

📌 **3. जीवन में इसका उपयोग (Actionable Step)**
[दृढ़ आवाज] केवल सुनने से बदलाव नहीं आता; जो सीखा है, उसे आज ही अपने जीवन में लागू कीजिए।
        """.trimIndent()

        val bodyHinglish = """
📌 **1. The Core Insight**
[Speak deeply] Jab hum '$topic' analyze karte hain, toh clear foundation samajhna sabse important hai.

📌 **2. Key Takeaway**
[With enthusiasm] Right mindset aur dedicated execution har goal ko achievable banata hai.

📌 **3. Practical Action**
[Firm tone] Sunne se nahi, action lene se change aayega. Start today!
        """.trimIndent()

        val ctaHindi = "🚀 [कॉल टू एक्शन] अगर यह जानकारी उपयोगी लगी हो, तो लाइक करें, कमेंट में अपने विचार बताएं और दोस्तों के साथ शेयर करें!"
        val ctaHinglish = "🚀 [Call To Action] Agar yeh information valuable lagi ho, toh LIKE karein aur SHARE karein!"

        val fullHindi = "$hookHindi\n\n$bodyHindi\n\n$ctaHindi"
        val fullHinglish = "$hookHinglish\n\n$bodyHinglish\n\n$ctaHinglish"
        val words = fullHindi.split("\\s+".toRegex()).size

        return VoiceScriptResult(
            title = "वॉयस-ओवर: $topic",
            hindiTitle = topic,
            scriptType = category,
            tone = tone,
            fullScriptHindi = fullHindi,
            fullScriptHinglish = fullHinglish,
            hookSegment = hookHindi,
            bodySegment = bodyHindi,
            ctaSegment = ctaHindi,
            estimatedDurationSeconds = (words / 2.5).toInt().coerceIn(30, 75),
            wordCount = words,
            teleprompterLines = fullHindi.split("\n").filter { it.isNotBlank() }
        )
    }
}
