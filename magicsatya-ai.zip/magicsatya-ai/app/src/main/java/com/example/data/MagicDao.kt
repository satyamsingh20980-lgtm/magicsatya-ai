package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MagicDao {
    @Query("SELECT * FROM magic_items ORDER BY timestamp DESC")
    fun getAllItems(): Flow<List<MagicItem>>

    @Query("SELECT * FROM magic_items WHERE category = :category ORDER BY timestamp DESC")
    fun getItemsByCategory(category: String): Flow<List<MagicItem>>

    @Query("SELECT * FROM magic_items WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteItems(): Flow<List<MagicItem>>

    @Query("SELECT * FROM magic_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): MagicItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: MagicItem): Long

    @Update
    suspend fun updateItem(item: MagicItem)

    @Delete
    suspend fun deleteItem(item: MagicItem)

    @Query("UPDATE magic_items SET isFavorite = :isFav WHERE id = :id")
    suspend fun setFavorite(id: Long, isFav: Boolean)

    @Query("DELETE FROM magic_items WHERE id = :id")
    suspend fun deleteById(id: Long)
}
