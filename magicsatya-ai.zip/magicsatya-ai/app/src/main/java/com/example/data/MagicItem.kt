package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "magic_items")
data class MagicItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // "STORY", "IMAGE", "VIDEO", "VOICE"
    val title: String,
    val hindiTitle: String = "",
    val promptInput: String,
    val generatedContent: String,
    val secondaryContent: String = "", // e.g. Negative prompt, Hinglish script, or parameters
    val styleOrGenre: String = "",
    val language: String = "Hindi", // "Hindi", "English", "Hinglish"
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
