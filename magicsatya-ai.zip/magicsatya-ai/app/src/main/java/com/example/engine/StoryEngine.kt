package com.example.engine

data class StoryResult(
    val title: String,
    val hindiTitle: String,
    val fullStory: String,
    val moralOrClimax: String,
    val characters: String,
    val wordCount: Int,
    val readingTimeMinutes: String
)

object StoryEngine {

    val genres = listOf(
        "Mythological & Epic (पौराणिक गाथा)",
        "Moral & Life Lessons (प्रेरणादायक सीख)",
        "Historical & Legends (ऐतिहासिक कथा)",
        "Sci-Fi & Future (विज्ञान व भविष्य)",
        "Drama & Emotions (भावना व जीवन)",
        "Horror & Thriller (रोमांचक रहस्य)",
        "Comedy & Wit (हास्य व चातुर्य)"
    )

    val tones = listOf(
        "Inspiring & Devotional (प्रेरणादायी व भक्तिमय)",
        "Epic & Grand (भव्य व रोमांचक)",
        "Emotional (भावुक व हृदयस्पर्शी)",
        "Suspenseful & Gripping (रोमांचक व रहस्यमयी)",
        "Simple & Pure (सरल व शुद्ध)"
    )

    val beginnerPrompts = listOf(
        "रामायण: प्रभु श्री राम का वनवास, सेतु निर्माण और धर्म की विजय",
        "महाभारत: कुरुक्षेत्र में भगवान श्री कृष्ण का अर्जुन को गीता ज्ञान",
        "पवनपुत्र हनुमान: संजीवनी बूटी लाने और लंका दहन की दिव्य गाथा",
        "गौतम बुद्ध और डाकू अंगुलिमाल: कैसे करुणा ने क्रूरता को बदला",
        "एक छोटे गांव के बच्चे का वैज्ञानिक बनकर अंतरिक्ष छूने का सपना"
    )

    suspend fun generateStoryAsync(
        topic: String,
        genre: String,
        tone: String,
        characterName: String,
        language: String,
        length: String
    ): StoryResult {
        val cleanTopic = if (topic.isNotBlank()) topic.trim() else "रामायण और प्रभु श्री राम की विजय"
        
        // Try Gemini API if available
        val isContinuous = cleanTopic.contains("continuous", ignoreCase = true) || 
                           cleanTopic.contains("एक ही narration", ignoreCase = true) ||
                           cleanTopic.contains("बिना भागों", ignoreCase = true) ||
                           cleanTopic.contains("voice-over", ignoreCase = true)

        val isEnglish = language.equals("English", ignoreCase = true) || 
                        cleanTopic.matches(Regex("^[a-zA-Z0-9\\s,.'!?\\-]+$")) && language != "Hindi"

        val systemPrompt = """
            You are MagicSatya AI, a world-class viral storyteller and scriptwriter specializing in Hindi and English stories for 60-90 second voice-overs and videos.
            Generate an authentic, high-quality, structured story based strictly on the user's exact topic: "$cleanTopic".
            
            Strict Formatting Rules:
            1. Format the story into exactly 4 clearly marked scenes/paragraphs so it is easy to generate visual/video prompts later:
               - **Scene 1 (Hook & Introduction / प्रारंभ):** Hook the audience in the first 3 seconds, introduce the setting and main characters.
               - **Scene 2 (Journey & Conflict / संघर्ष):** Describe the central quest, challenge, or rising action.
               - **Scene 3 (The Climax / चरमोत्कर्ष):** The high-stakes turning point, battle, or moment of transformation.
               - **Scene 4 (Resolution & Wisdom / सीख):** The conclusion, victory of truth/virtue, and lasting impact.
            2. Length: Around 140-200 words (ideal for a 60–90 second voice-over).
            3. If the topic is about Ramayana, Mahabharata, Shiva, Hanuman, or historical epics, use real authentic lore and names (Lord Ram, Sita, Lakshman, Hanuman, Ravana, Krishna, Arjuna, etc.).
            4. Language: ${if (isEnglish) "High-quality, engaging English" else "Rich, authentic, pure Hindi"}.
            5. Provide a compelling title and moral/key takeaway.
        """.trimIndent()

        val userPrompt = """
            Topic: $cleanTopic
            Genre: $genre
            Tone: $tone
            Character Name: ${if (characterName.isNotBlank()) characterName else "Authentic characters"}
            Language: ${if (isEnglish) "English" else "Hindi"}
            Target Duration: 60-90 seconds voice-over
        """.trimIndent()

        val aiResult = GeminiService.generateContent(systemPrompt, userPrompt)
        if (aiResult != null && aiResult.isNotBlank()) {
            return parseGeminiStoryResponse(aiResult, cleanTopic, if (isEnglish) "English" else "Hindi")
        }

        // Offline intelligent fallback engine
        return generateStory(cleanTopic, genre, tone, characterName, if (isEnglish) "English" else language, length)
    }

    private fun parseGeminiStoryResponse(aiText: String, topic: String, language: String): StoryResult {
        val words = aiText.split("\\s+".toRegex()).size
        val isEng = language.equals("English", ignoreCase = true)
        val readTime = "60–90 सेकंड (Voice-Over Ready)"

        return StoryResult(
            title = topic.take(50),
            hindiTitle = topic.take(50),
            fullStory = aiText,
            moralOrClimax = if (isEng) "✨ Moral: Truth, courage, and righteousness always prevail." else "✨ सीख: सत्य, धर्म और अटूट संकल्प की सदैव विजय होती है।",
            characters = if (isEng) "Key characters of the story" else "कथा के प्रमुख पात्र",
            wordCount = words,
            readingTimeMinutes = readTime
        )
    }

    fun generateStory(
        topic: String,
        genre: String,
        tone: String,
        characterName: String,
        language: String, // "Hindi", "Hinglish", "English"
        length: String // "60-90s Reel", "Medium Story (3m)", "Long Epic (5m)"
    ): StoryResult {
        val cleanTopic = if (topic.isNotBlank()) topic.trim() else "रामायण: प्रभु श्री राम का धर्म युद्ध"
        val lower = cleanTopic.lowercase()
        val isEng = language.equals("English", ignoreCase = true)

        // 1. RAMAYANA
        if (lower.contains("राम") || lower.contains("ramayan") || lower.contains("रामायण") ||
            lower.contains("सीता") || lower.contains("हनुमान") || lower.contains("रावण") ||
            lower.contains("अयोध्या") || lower.contains("लंका") || lower.contains("दशरथ") ||
            lower.contains("लक्ष्मण") || lower.contains("shree ram") || lower.contains("rama")) {
            return generateRamayanaStory(cleanTopic, isEng)
        }

        // 2. MAHABHARATA
        if (lower.contains("महाभारत") || lower.contains("mahabharat") || lower.contains("कृष्ण") ||
            lower.contains("अर्जुन") || lower.contains("कर्ण") || lower.contains("कुरुक्षेत्र") ||
            lower.contains("गीता") || lower.contains("krishna") || lower.contains("arjun") ||
            lower.contains("पांडव") || lower.contains("कौरव") || lower.contains("भीष्म")) {
            return generateMahabharataStory(cleanTopic, isEng)
        }

        // 3. LORD SHIVA / MAHADEV
        if (lower.contains("शिव") || lower.contains("महादेव") || lower.contains("भोलेनाथ") ||
            lower.contains("shiva") || lower.contains("mahadev") || lower.contains("कैलाश") ||
            lower.contains("तांडव") || lower.contains("नीलकंठ") || lower.contains("पार्वती")) {
            return generateShivaStory(cleanTopic, isEng)
        }

        // 4. HANUMAN JI
        if (lower.contains("हनुमान") || lower.contains("बजरंगबली") || lower.contains("hanuman") ||
            lower.contains("संजीवनी") || lower.contains("सुंदरकांड") || lower.contains("पवनपुत्र")) {
            return generateHanumanStory(cleanTopic, isEng)
        }

        // 5. GAUTAM BUDDHA
        if (lower.contains("बुद्ध") || lower.contains("buddha") || lower.contains("अंगुलिमाल") ||
            lower.contains("सिद्धार्थ") || lower.contains("ज्ञान") || lower.contains("निर्वाण")) {
            return generateBuddhaStory(cleanTopic, isEng)
        }

        // 6. CHANAKYA & CHANDRAGUPTA
        if (lower.contains("चाणक्य") || lower.contains("chanakya") || lower.contains("चंद्रगुप्त") ||
            lower.contains("मगध") || lower.contains("अर्थशास्त्र")) {
            return generateChanakyaStory(cleanTopic, isEng)
        }

        // 7. PANCHATANTRA / CLEVER ANIMAL FABLE
        if (lower.contains("पंचतंत्र") || lower.contains("panchatantra") || lower.contains("शेर") ||
            lower.contains("खरगोश") || lower.contains("लोमड़ी") || lower.contains("बंदर") || lower.contains("कौआ") ||
            lower.contains("rabbit") || lower.contains("lion")) {
            return generatePanchatantraStory(cleanTopic, isEng)
        }

        // 8. SCI-FI / FUTURE / SPACE
        if (lower.contains("रोबोट") || lower.contains("ai") || lower.contains("अंतरिक्ष") ||
            lower.contains("space") || lower.contains("robot") || lower.contains("टाइम मशीन") ||
            lower.contains("मंगल") || lower.contains("भविष्य") || lower.contains("एलियन") ||
            lower.contains("mars") || lower.contains("future")) {
            return generateSciFiStory(cleanTopic, characterName, isEng)
        }

        // 9. DYNAMIC CONTEXTUAL STORY ENGINE FOR ANY CUSTOM USER TOPIC
        return generateDynamicContextualStory(cleanTopic, genre, tone, characterName, isEng)
    }

    private fun generateRamayanaStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Ramayana: The Epic Victory of Righteousness"
            val hindiTitle = "Story of Lord Rama, Sita, Lakshman, Hanuman & Ravana"
            val storyText = """
**Scene 1 (Hook & Introduction):**
In ancient Ayodhya, Crown Prince Rama embraced a 14-year exile without a moment's hesitation to honor his father King Dasharatha's sacred vow, accompanied by his devoted wife Sita and brother Lakshmana.

**Scene 2 (Journey & Conflict):**
When the ten-headed demon king Ravana abducted Sita through deception to Lanka, Lord Rama united with the devoted warrior Hanuman and King Sugriva. Together, the vanara army built the legendary floating Ram Setu bridge across the roaring ocean.

**Scene 3 (The Climax):**
A monumental battle shook the shores of Lanka. Following intense combat against Kumbhakarna and Meghanada, Lord Rama unleashed his divine Brahmastra arrow, piercing Ravana's invincible armor and shattering his reign of terror.

**Scene 4 (Resolution & Moral):**
Rescuing Sita, Lord Rama returned victoriously to Ayodhya, welcomed by a radiant sea of golden oil lamps (Diwali), proving that righteousness always triumphs over arrogance.
            """.trimIndent()
            val moral = "✨ Moral: No matter how powerful ego appears, truth and righteousness always triumph."
            val characters = "Lord Rama, Mata Sita, Lakshmana, Hanuman Ji, Sugriva, Ravana"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "रामायण: मर्यादा पुरुषोत्तम श्री राम और धर्म की विजय"
        val hindiTitle = "श्री राम, सीता माता, लक्ष्मण, हनुमान जी और रावण वध की अमर कथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
अयोध्या के राजकुमार मर्यादा पुरुषोत्तम श्री राम ने अपने पिता के एक वचन की रक्षा के लिए राजपाट त्यागकर 14 वर्ष का वनवास सहर्ष स्वीकार किया। उनके साथ माता सीता और अनुज लक्ष्मण भी वन की ओर चल पड़े।

**Scene 2 (यात्रा व संघर्ष):**
पंचवटी में लंकापति रावण ने छल से माता सीता का हरण कर लिया। सीता जी की खोज में प्रभु श्री राम की भेंट परम भक्त पवनपुत्र हनुमान और सुग्रीव से हुई। वानर सेना के अथक श्रम से विशाल समुद्र पर तैरते पत्थरों का राम-सेतु तैयार हुआ।

**Scene 3 (महासंग्राम व क्लाइमेक्स):**
लंका के मैदान में धर्म और अधर्म का भीषण युद्ध हुआ। कुंभकर्ण और मेघनाद के वध के बाद, अंततः प्रभु श्री राम ने अपने अचूक बाण से दस सिर वाले अहंकारी रावण का संहार कर माता सीता को मुक्त कराया।

**Scene 4 (समापन व अमर सीख):**
प्रभु श्री राम जब अयोध्या लौटे, तो पूरी प्रजा ने घी के दीये जलाकर उनका स्वागत किया। रामायण हमें सिखाती है कि अहंकार का नाश निश्चित है और धर्म की विजय सदैव शाश्वत है।
        """.trimIndent()

        val moral = "✨ सीख: अधर्म और अहंकार कितना भी शक्तिशाली क्यों न हो, अंत में विजय सदैव सत्य और मर्यादा की ही होती है।"
        val characters = "प्रभु श्री राम, माता सीता, लक्ष्मण, हनुमान जी, सुग्रीव, रावण"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateMahabharataStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Mahabharata: The Battlefield of Kurukshetra & Gita's Wisdom"
            val hindiTitle = "Lord Krishna, Arjuna, and the Divine Bhagavad Gita"
            val storyText = """
**Scene 1 (Hook & Introduction):**
On the sacred battlefield of Kurukshetra, vast armies of Pandavas and Kauravas stood face-to-face, ready for the greatest war in history.

**Scene 2 (Journey & Conflict):**
Seeing his beloved kin and teachers arrayed against him, the master archer Arjuna collapsed in deep sorrow, dropping his Gandiva bow in despair.

**Scene 3 (The Climax):**
Stepping forward as Arjuna's divine charioteer, Lord Krishna revealed the timeless wisdom of the Bhagavad Gita—teaching that the soul is immortal, and one must perform selfless duty without attachment to the outcome.

**Scene 4 (Resolution & Moral):**
Awakened by Krishna's words, Arjuna blew his conch shell and led the Pandavas to victory over injustice, establishing righteous order across the world.
            """.trimIndent()
            val moral = "✨ Moral: Perform your duty wholeheartedly without anxiety for results; truth always leads to victory."
            val characters = "Lord Krishna, Arjuna, Karna, Bhishma, Yudhishthira, Duryodhana"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "महाभारत: कुरुक्षेत्र का महासंग्राम और गीता का अमर ज्ञान"
        val hindiTitle = "श्री कृष्ण, अर्जुन, कर्ण और धर्मक्षेत्र कुरुक्षेत्र की गाथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
कुरुक्षेत्र के मैदान में जब पांडवों और कौरवों की विशाल सेनाएं आमने-सामने खड़ी थीं, तब धनुर्धर अर्जुन अपनों को सामने देखकर मोह और संशय से घिर गए और उनका गांडीव धनुष हाथ से छूटने लगा।

**Scene 2 (उपदेश व संघर्ष):**
तभी उनके सारथी भगवान श्री कृष्ण ने अर्जुन को 'श्रीमद्भगवद्गीता' का अमर उपदेश दिया। श्री कृष्ण ने समझाया कि आत्मा अजर-अमर है; मनुष्य का अधिकार केवल निष्काम कर्म पर है, फल पर नहीं।

**Scene 3 (महासंग्राम):**
गीता के दिव्य ज्ञान से जागृत होकर अर्जुन ने गांडीव उठाया। भीष्म, द्रोण और कर्ण जैसे महारथियों के पराक्रम के बीच 18 दिनों के भीषण धर्मयुद्ध में अधर्म का समूल नाश हुआ।

**Scene 4 (समापन व संदेश):**
महाभारत सिखाती है कि जहां धर्म है, वहां श्री कृष्ण हैं, और जहां श्री कृष्ण हैं, वहां विजय निश्चित है।
        """.trimIndent()

        val moral = "✨ सीख: 'कर्मण्येवाधिकारस्ते मा फलेषु कदाचन'—निस्वार्थ भाव से किया गया धर्मसम्मत कर्म ही मनुष्य को विजयी बनाता है।"
        val characters = "भगवान श्री कृष्ण, अर्जुन, कर्ण, भीष्म पितामह, युधिष्ठिर, दुर्योधन"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateShivaStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Lord Shiva: The Legend of Neelkantha & Cosmic Compassion"
            val hindiTitle = "Lord Shiva and the Ocean of Poison"
            val storyText = """
**Scene 1 (Hook & Introduction):**
During the epic churning of the cosmic ocean by gods and demons in search of immortal nectar, a deadly blue venom called Halahala emerged first, threatening to incinerate the three worlds.

**Scene 2 (Journey & Conflict):**
In absolute panic, all deities fled to Mount Kailash, pleading for the mercy of Mahadev—the supreme ascetic Lord Shiva.

**Scene 3 (The Climax):**
Without a single hesitation, Lord Shiva gathered the deadly poison into his palm and drank it to protect creation. Goddess Parvati gently held his throat to prevent the toxin from spreading.

**Scene 4 (Resolution & Moral):**
The poison turned Shiva's throat deep sapphire blue, earning Him the revered name 'Neelkantha'—a supreme symbol of selfless sacrifice for the universe.
            """.trimIndent()
            val moral = "✨ Moral: True greatness lies in absorbing negativity to protect and uplift others."
            val characters = "Lord Shiva (Neelkantha), Goddess Parvati, Lord Indra, Devas & Asuras"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "देवों के देव महादेव: त्याग, वैराग्य और महाकाल की शक्ति"
        val hindiTitle = "भगवान शिव और समुद्र मंथन के विषपान की कथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
जब देवताओं और असुरों ने अमृत पाने के लिए क्षीरसागर का मंथन किया, तो अमृत से पहले हलाहल नाम का प्रलयंकारी विष निकला, जिसकी ज्वाला से तीनों लोक जलने लगे।

**Scene 2 (प्रार्थना व शरण):**
समस्त देवता और दानव त्राहि-त्राहि करते हुए कैलाश पर्वत पर भगवान शिव की शरण में पहुंचे और सृष्टि की रक्षा की गुहार लगाई।

**Scene 3 (विषपान व त्याग):**
करुणामयी भोलेनाथ ने बिना एक पल सोचे उस कालकूट विष को अपनी हथेली पर रखकर पी लिया। माता पार्वती ने विष को शरीर में फैलने से रोकने के लिए शिव के कंठ को थाम लिया।

**Scene 4 (समापन व संदेश):**
विष के प्रभाव से महादेव का कंठ नीला पड़ गया और वे 'नीलकंठ' कहलाए। भगवान शिव सिखाते हैं कि दूसरों के कल्याण के लिए त्याग करना ही सबसे बड़ा धर्म है।
        """.trimIndent()

        val moral = "✨ सीख: सच्चा सामर्थ्य दूसरों के कल्याण के लिए विष पी लेने और शांति बनाए रखने में है।"
        val characters = "भगवान शिव (नीलकंठ), माता पार्वती, देवराज इंद्र, देवता व असुर"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateHanumanStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Sankatmochan Hanuman: Faith, Might & Sanjeevani"
            val hindiTitle = "Hanuman Ji carrying the Dronagiri Mountain"
            val storyText = """
**Scene 1 (Hook & Introduction):**
When Lakshmana fell fatally unconscious on the battlefield from Meghanada's mystical weapon, physician Sushena declared only the rare Sanjeevani herb from the distant Himalayas could save his life before dawn.

**Scene 2 (Journey & Conflict):**
Receiving Lord Rama's blessings, Hanuman leaped across hundreds of leagues through the midnight sky and arrived at Mount Dronagiri.

**Scene 3 (The Climax):**
Unable to identify the glowing herb among thousands of magical plants, Hanuman wasted no precious moments—he expanded into colossal form and lifted the entire mountain peak on his hand!

**Scene 4 (Resolution & Moral):**
Soaring back to Lanka before sunrise, Hanuman revived Lakshmana, proving that unwavering devotion and courage can move mountains.
            """.trimIndent()
            val moral = "✨ Moral: With pure devotion and fearless belief, no obstacle is insurmountable."
            val characters = "Hanuman Ji, Lord Rama, Lakshmana, Physician Sushena"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "संकटमोचन हनुमान: भक्ति, अतुलित बल और संजीवनी की गाथा"
        val hindiTitle = "पवनपुत्र हनुमान जी की असीम निष्ठा और पराक्रम"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
युद्धभूमि में मेघनाद के शक्ति बाण से जब लक्ष्मण जी मूर्छित हो गए, तो लंका के वैद्य सुषेण ने कहा कि सूर्योदय से पूर्व हिमालय की द्रोणागिरि पर्वत से 'संजीवनी बूटी' लानी होगी।

**Scene 2 (पवन वेग से यात्रा):**
प्रभु श्री राम की आज्ञा लेकर पवनपुत्र हनुमान ने एक छलांग में सैकड़ों योजन की दूरी तय की और पलक झपकते ही हिमालय पहुंच गए।

**Scene 3 (पर्वत उठाना व पराक्रम):**
पर्वत पर चमकती वनस्पतियों में संजीवनी न पहचान पाने पर समय व्यर्थ किए बिना हनुमान जी ने पूरे पर्वत शिखर को ही अपनी हथेली पर उठा लिया।

**Scene 4 (समापन व संदेश):**
सूर्योदय से पूर्व लंका लौटकर हनुमान जी ने लक्ष्मण के प्राण बचाए। यह गाथा सिखाती है कि प्रभु भक्ति और दृढ़ संकल्प से हर असंभव कार्य संभव हो जाता है।
        """.trimIndent()

        val moral = "✨ सीख: अटूट भक्ति और आत्मविश्वास से हर असंभव बाधा को पार किया जा सकता है।"
        val characters = "पवनपुत्र हनुमान, प्रभु श्री राम, लक्ष्मण, वैद्य सुषेण"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateBuddhaStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Gautama Buddha & Angulimala: The Victory of Compassion"
            val hindiTitle = "How Lord Buddha Transformed a Feared Bandit"
            val storyText = """
**Scene 1 (Hook & Introduction):**
In the dense forests of Magadha lived Angulimala, a ruthless bandit feared by kings, who wore a garland of fingers cut from his victims.

**Scene 2 (Journey & Conflict):**
Gautama Buddha walked calmly into the dark forest. Rushing with a sword, Angulimala shouted, 'Stop, monk!' Buddha replied peacefully, 'I stopped long ago, Angulimala; when will you stop?'

**Scene 3 (The Climax):**
Stunned by Buddha's radiant fearlessness, the bandit listened as the Master explained that harming others is weakness, while love and compassion require supreme strength.

**Scene 4 (Resolution & Moral):**
Throwing down his bloody sword, Angulimala wept at Buddha's feet and embraced the noble path of non-violence and enlightenment.
            """.trimIndent()
            val moral = "✨ Moral: Hatred is never overcome by hatred; only love and compassion can conquer it."
            val characters = "Lord Gautama Buddha, Angulimala"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "भगवान बुद्ध और अंगुलिमाल: हिंसा पर करुणा की विजय"
        val hindiTitle = "महात्मा बुद्ध के प्रेम से कैसे बदला एक क्रूर डाकू"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
मगध के घने जंगलों में अंगुलिमाल नाम का खूंखार डाकू रहता था, जो राहगीरों को मारकर उनकी उंगलियों की माला पहनता था। पूरे राज्य में उसका आतंक था।

**Scene 2 (भेंट व संवाद):**
एक दिन भगवान बुद्ध निडर होकर उस जंगल की ओर बढ़े। डाकू ने तलवार चमकाते हुए कहा, 'रुक जा संन्यासी!' बुद्ध मुस्कुराए और बोले, 'मैं तो कब का रुक गया, तू कब रुकेगा?'

**Scene 3 (हृदय परिवर्तन):**
बुद्ध की आंखों में असीम करुणा और निर्भयता देखकर डाकू स्तब्ध रह गया। बुद्ध ने समझाया कि मारना आसान है, जीवन देना महान; घृणा को केवल प्रेम ही जीत सकता है।

**Scene 4 (समापन व सीख):**
बुद्ध के वचनों से डाकू का अंधकार मिट गया। उसने तलवार फेंक दी और बुद्ध के चरणों में गिरकर अहिंसा का मार्ग अपना लिया।
        """.trimIndent()

        val moral = "✨ सीख: घृणा को घृणा से नहीं, केवल प्रेम और करुणा से ही जीता जा सकता है।"
        val characters = "भगवान गौतम बुद्ध, डाकू अंगुलिमाल"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateChanakyaStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Chanakya & Chandragupta: The Birth of an Empire"
            val hindiTitle = "How Chanakya turned a Village Boy into a Mighty Emperor"
            val storyText = """
**Scene 1 (Hook & Introduction):**
When the arrogant King Dhanananda publicly insulted Acharya Chanakya in the court of Magadha, the sage untied his lock of hair, vowing never to bind it until the tyrannical dynasty was overthrown.

**Scene 2 (Journey & Conflict):**
Chanakya discovered a brave young village boy named Chandragupta. Through rigorous training in statecraft, military strategy, and economics, Chanakya forged him into a master warrior.

**Scene 3 (The Climax):**
Uniting scattered tribes and defeating foreign invaders, Chanakya and Chandragupta toppled the oppressive empire of Magadha in a decisive masterstroke of strategy.

**Scene 4 (Resolution & Moral):**
They founded the golden Maurya Empire, proving that sharp intellect and unbending determination can turn an ordinary boy into an emperor.
            """.trimIndent()
            val moral = "✨ Moral: Wisdom, discipline, and strategic vision can conquer any empire."
            val characters = "Acharya Chanakya, Emperor Chandragupta Maurya, King Dhanananda"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "आचार्य चाणक्य और चंद्रगुप्त: अखंड भारत का निर्माण"
        val hindiTitle = "कूटनीति, प्रतिज्ञा और एक साधारण बालक से सम्राट बनने की गाथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
जब मगध के अहंकारी राजा धनानंद ने आचार्य चाणक्य का अपमान किया, तो चाणक्य ने प्रतिज्ञा ली कि जब तक वे इस अन्यायी शासन का अंत नहीं कर देंगे, तब तक अपनी शिखा नहीं बांधेंगे।

**Scene 2 (तैयारी व रणनीति):**
चाणक्य ने एक होनहार बालक चंद्रगुप्त को चुना और अपनी अद्वितीय कूटनीति, अर्थशास्त्र और युद्ध कौशल से उसे एक महान नायक के रूप में तैयार किया।

**Scene 3 (क्रांति व विजय):**
विदेशी आक्रांताओं को खदेड़कर और धनानंद के अत्याचारों का अंत करके चाणक्य और चंद्रगुप्त ने पाटलिपुत्र पर विजय प्राप्त की।

**Scene 4 (समापन व संदेश):**
मौर्य साम्राज्य की स्थापना से अखंड भारत का सपना साकार हुआ। चाणक्य नीति सिखाती है कि साधन भले सीमित हों, दृढ़ संकल्प से इतिहास रचा जा सकता है।
        """.trimIndent()

        val moral = "✨ सीख: तीक्ष्ण बुद्धि और अडिग संकल्प से साधारण व्यक्ति भी विश्व विजेता सम्राट बन सकता है।"
        val characters = "आचार्य चाणक्य, चंद्रगुप्त मौर्य, राजा धनानंद"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generatePanchatantraStory(topic: String, isEnglish: Boolean): StoryResult {
        if (isEnglish) {
            val title = "Panchatantra: Wisdom Beats Brute Strength"
            val hindiTitle = "The Clever Rabbit and the Ferocious Lion"
            val storyText = """
**Scene 1 (Hook & Introduction):**
In a deep jungle, a ferocious lion named Bhasuraka terrorized innocent animals, demanding one victim be sent to his den every single day.

**Scene 2 (Journey & Conflict):**
When the turn came for a tiny, clever rabbit, he intentionally arrived late. When the starving lion roared in fury, the rabbit whispered that another lion had claimed lordship over the forest.

**Scene 3 (The Climax):**
Enraged, the lion demanded to see this rival. The rabbit led him to a deep water well. Looking down, the lion saw his own fierce reflection and heard his echoing roar.

**Scene 4 (Resolution & Moral):**
Believing it was his enemy, the foolish lion leaped into the well to attack and drowned, freeing the entire forest through the rabbit's sharp wit.
            """.trimIndent()
            val moral = "✨ Moral: Intelligence and presence of mind can defeat even the mightiest brute force."
            val characters = "Clever Rabbit, Lion Bhasuraka, Forest Animals"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "पंचतंत्र की बुद्धिमानी: बल से बढ़कर बुद्धि"
        val hindiTitle = "चतुर खरगोश और अहंकारी शेर भासुरक की कथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
एक घने जंगल में भासुरक नाम का बलशाली शेर रहता था, जो प्रतिदिन बेकसूर जानवरों का शिकार करता था। जानवरों ने तय किया कि रोज एक पशु स्वयं उसके भोजन के लिए जाएगा।

**Scene 2 (चतुर योजना):**
जब एक छोटे खरगोश की बारी आई, तो वह जानबूझकर देर से पहुंचा। क्रोधित शेर के पूछने पर खरगोश ने कहा कि रास्ते में उसे एक दूसरा शेर मिला जो खुद को जंगल का राजा बता रहा था।

**Scene 3 (कुएं का क्लाइमेक्स):**
गुस्से में शेर ने कहा, 'मुझे उसके पास ले चलो!' खरगोश उसे गहरे कुएं के पास ले गया। कुएं के पानी में अपनी ही परछाई और गूंज सुनकर शेर ने दूसरे शेर पर हमला करने के लिए कुएं में छलांग लगा दी।

**Scene 4 (समापन व संदेश):**
अहंकारी शेर पानी में डूब गया और छोटे खरगोश ने अपनी अक्ल से पूरे जंगल को बचा लिया।
        """.trimIndent()

        val moral = "✨ सीख: 'बुद्धिर्यस्य बलं तस्य'—जिसके पास बुद्धि है, उसी के पास वास्तविक बल है।"
        val characters = "चतुर खरगोश, शेर भासुरक, जंगल के अन्य पशु"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateSciFiStory(topic: String, characterName: String, isEnglish: Boolean): StoryResult {
        val hero = if (characterName.isNotBlank()) characterName.trim() else (if (isEnglish) "Dr. Aarav" else "डॉ. आरव")
        if (isEnglish) {
            val title = "Echoes of the Future: $topic"
            val hindiTitle = "$hero and the Cosmic Energy Core"
            val storyText = """
**Scene 1 (Hook & Introduction):**
In the year 2085, as Earth's natural reserves reached critical depletion, visionary scientist $hero discovered an ancient zero-point energy matrix on Mars.

**Scene 2 (Journey & Conflict):**
A sudden catastrophic solar storm struck the research station, severing all communications and disabling primary orbital thrusters.

**Scene 3 (The Climax):**
With oxygen failing and the team losing hope, $hero manually recalibrated the experimental quantum core in zero gravity under intense cosmic radiation.

**Scene 4 (Resolution & Moral):**
The core sparked to life, restoring navigation and powering a new era of clean energy for humanity across the stars.
            """.trimIndent()
            val moral = "✨ Moral: Human courage and scientific curiosity can illuminate the darkest horizons."
            val characters = "$hero, Expedition Space Crew"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = "भविष्य की गूंज: $topic"
        val hindiTitle = "$hero और अंतरिक्ष का नया सवेरा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
वर्ष 2085 में जब पृथ्वी के ऊर्जा स्रोत समाप्त होने की कगार पर थे, तब युवा वैज्ञानिक $hero ने मंगल ग्रह की गहराइयों में एक प्राचीन ऊर्जा मैट्रिक्स की खोज की।

**Scene 2 (संकट व संघर्ष):**
अंतरिक्ष स्टेशन पर अचानक सौर तूफ़ान आने से सारा संचार तंत्र ठप हो गया और क्रू का संपर्क पृथ्वी से टूट गया।

**Scene 3 (क्लाइमेक्स व समाधान):**
विषम परिस्थितियों में $hero ने अपने स्वदेशी क्वांटम एल्गोरिदम का उपयोग करके इमरजेंसी थ्रस्टर्स को सक्रिय किया और उस ऊर्जा कोर को सुरक्षित बचाया।

**Scene 4 (समापन व संदेश):**
यह कहानी साबित करती है कि मानवीय साहस और विज्ञान का संगम ब्रह्मांड के किसी भी अंधेरे को चीरकर नई रोशनी पैदा कर सकता है।
        """.trimIndent()

        val moral = "✨ सीख: विज्ञान और मानवीय साहस जब एक साथ मिलते हैं, तो असंभव भी संभव हो जाता है।"
        val characters = "$hero (मुख्य वैज्ञानिक), अंतरिक्ष अनुसंधान दल"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }

    private fun generateDynamicContextualStory(
        topic: String,
        genre: String,
        tone: String,
        characterName: String,
        isEnglish: Boolean
    ): StoryResult {
        val hero = if (characterName.isNotBlank()) characterName.trim() else (if (isEnglish) "The Protagonist" else "मुख्य पात्र")
        if (isEnglish) {
            val title = topic.take(45)
            val hindiTitle = "Story of $topic"
            val storyText = """
**Scene 1 (Hook & Introduction):**
This is the captivating story centered around '$topic', where an extraordinary journey began in the face of uncertainty.

**Scene 2 (Journey & Conflict):**
When unforeseen hurdles and testing obstacles blocked every path, $hero refused to surrender, standing firm on truth, integrity, and relentless perseverance.

**Scene 3 (The Climax & Breakthrough):**
At the darkest hour when hope seemed lost, a bold decision and courageous action turned the entire tide, overcoming the ultimate challenge.

**Scene 4 (Resolution & Moral):**
The breakthrough inspired everyone around, proving that clear vision, unwavering courage, and honest dedication always lead to lasting triumph.
            """.trimIndent()
            val moral = "✨ Moral: No obstacle is permanent for a determined heart; true dedication always creates history."
            val characters = "$hero, companions & mentors"
            return StoryResult(title, hindiTitle, storyText, moral, characters, storyText.split("\\s+".toRegex()).size, "60–90s Voice-Over")
        }

        val title = topic.take(45)
        val hindiTitle = "$topic: एक प्रेरणादायक गाथा"

        val storyText = """
**Scene 1 (प्रारंभ व हुक):**
यह गाथा है '$topic' के इर्द-गिर्द बुने गए एक सच्चे संघर्ष और अटूट संकल्प की, जिसने असंभव को संभव बना दिया।

**Scene 2 (यात्रा व संघर्ष):**
जीवन की राह पर जब हर तरफ चुनौतियां और अनिश्चितता के बादल छाए हुए थे, तब $hero ने हार मानने के बजाय अपने सिद्धांतों और आत्मबल को अपनी ढाल बनाया।

**Scene 3 (चरमोत्कर्ष व मोड़):**
कठिन से कठिन मोड़ पर जब सबने उम्मीद छोड़ दी थी, तब उनकी अडिग निष्ठा और साहसिक निर्णय ने पूरे खेल का रुख मोड़ दिया।

**Scene 4 (समापन व संदेश):**
अथक प्रयासों के बल पर अंततः उन्होंने वह मुकाम हासिल किया जो दूसरों के लिए मिसाल बन गया। नेक इरादे और सच्ची लगन सदा विजयी होती है।
        """.trimIndent()

        val moral = "✨ सीख: संकल्पवान व्यक्ति के लिए कोई भी बाधा स्थाई नहीं होती; सच्ची मेहनत सदा रंग लाती है।"
        val characters = "$hero, मार्गदर्शक व सहयोगी"
        val wordCount = storyText.split("\\s+".toRegex()).size

        return StoryResult(
            title = title,
            hindiTitle = hindiTitle,
            fullStory = storyText,
            moralOrClimax = moral,
            characters = characters,
            wordCount = wordCount,
            readingTimeMinutes = "60–90 सेकंड (Voice-Over Ready)"
        )
    }
}
