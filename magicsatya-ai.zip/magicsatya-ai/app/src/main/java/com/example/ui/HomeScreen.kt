package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ImagePromptColor
import com.example.ui.theme.MagicGold
import com.example.ui.theme.MagicPrimary
import com.example.ui.theme.MagicSecondary
import com.example.ui.theme.StoryColor
import com.example.ui.theme.VideoPromptColor
import com.example.ui.theme.VoiceScriptColor

@Composable
fun HomeScreen(
    viewModel: MagicViewModel,
    onNavigateToStory: () -> Unit,
    onNavigateToImage: () -> Unit,
    onNavigateToVideo: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToVault: () -> Unit
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isHindi = language == AppLanguage.HINDI
    val savedItems by viewModel.savedItems.collectAsState()

    Scaffold(
        topBar = {
            MagicTopBar(
                title = "MagicSatya AI",
                subtitle = if (isHindi) "स्मार्ट क्रिएटिव एआई स्टूडियो" else "Smart Creative AI Studio",
                currentLanguage = language,
                onLanguageToggle = { viewModel.toggleLanguage() },
                onVaultClick = onNavigateToVault,
                savedCount = savedItems.size
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Welcome Banner
            item(key = "home_hero_banner") {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline,
                            RoundedCornerShape(24.dp)
                        )
                        .testTag("hero_banner_card")
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Background artwork banner
                        Image(
                            painter = painterResource(id = R.drawable.magic_satya_hero),
                            contentDescription = "MagicSatya Studio Banner",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentScale = ContentScale.Crop
                        )

                        // Deep Oceanic gradient overlay for text legibility & minimalist feel
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color(0xB300263D),
                                            Color(0xF0001B2C)
                                        )
                                    )
                                )
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                                .align(Alignment.BottomStart)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0x33FFFFFF)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "✨ 100% Free AI Studio",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            ),
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (isHindi) "आज आप क्या बनाना चाहते हैं?" else "What do you want to create today?",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 19.sp
                                ),
                                color = Color.White
                            )

                            Text(
                                text = if (isHindi) "कहानी, इमेज प्रॉम्प्ट, वीडियो आइडिया या रील्स स्क्रिप्ट बनाएं" else "Generate stories, art prompts, cinematic videos & voice scripts",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 12.sp
                                ),
                                color = Color(0xFFD6E8FF)
                            )
                        }
                    }
                }
            }

            // Quick Studio Section Header
            item(key = "home_features_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isHindi) "🚀 4 मुख्य एआई फीचर्स" else "🚀 4 Core AI Features",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = if (isHindi) "आसान व तेज" else "Easy & Fast",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // 1. Story Generator Card
            item(key = "card_feature_story") {
                MainFeatureCard(
                    title = "Story Generator",
                    hindiTitle = "📖 कहानी जनरेटर",
                    subtitle = if (isHindi) "बच्चों की सीख, सस्पेंस, रोमांस और पौराणिक कथाएं बनाएं। सुनिए और शेयर करें।" else "Create moral tales, sci-fi mystery, epics, & romance with audio narrations.",
                    badgeText = if (isHindi) "ऑडियो सहित" else "Audio Narrator",
                    iconEmoji = "📚",
                    accentColor = StoryColor,
                    onClick = onNavigateToStory,
                    testTag = "home_card_story"
                )
            }

            // 2. Image Prompt Card
            item(key = "card_feature_image") {
                MainFeatureCard(
                    title = "Image Prompt",
                    hindiTitle = "🎨 इमेज प्रॉम्प्ट (AI Art)",
                    subtitle = if (isHindi) "Midjourney, Flux और DALL-E के लिए 8K अल्ट्रा-डिटेल प्रॉम्प्ट और नेगेटिव प्रॉम्प्ट।" else "Optimized master prompts with camera lens, lighting & Midjourney tags.",
                    badgeText = "Midjourney / Flux",
                    iconEmoji = "🖼️",
                    accentColor = ImagePromptColor,
                    onClick = onNavigateToImage,
                    testTag = "home_card_image"
                )
            }

            // 3. Video Prompt Card
            item(key = "card_feature_video") {
                MainFeatureCard(
                    title = "Video Prompt",
                    hindiTitle = "🎬 वीडियो प्रॉम्प्ट (Sora / Runway)",
                    subtitle = if (isHindi) "Runway Gen-3 और Sora के लिए कैमरा मोशन (ड्रोन, पैन, एफपीवी) और वीएफएक्स प्रॉम्प्ट।" else "Camera dynamics, drone orbit, dolly zoom, and motion prompts for AI video.",
                    badgeText = "Sora & Runway",
                    iconEmoji = "🎥",
                    accentColor = VideoPromptColor,
                    onClick = onNavigateToVideo,
                    testTag = "home_card_video"
                )
            }

            // 4. Voice-over Script Card
            item(key = "card_feature_voice") {
                MainFeatureCard(
                    title = "Voice-over Script",
                    hindiTitle = "🎙️ वॉयस-ओवर स्क्रिप्ट",
                    subtitle = if (isHindi) "Reels, Shorts और Podcasts के लिए 30s हुक + बॉडी + कॉल टू एक्शन और टेलीप्रॉम्प्टर।" else "Viral hooks, motivation, ads, teleprompter mode with voice reader.",
                    badgeText = if (isHindi) "टेलीप्रॉम्प्टर" else "Teleprompter",
                    iconEmoji = "🎙️",
                    accentColor = VoiceScriptColor,
                    onClick = onNavigateToVoice,
                    testTag = "home_card_voice"
                )
            }

            // Quick Beginner Tips & Inspiration
            item(key = "card_beginner_tips") {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "Tip",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isHindi) "शुरुआती टिप (Beginner Tip)" else "Beginner Studio Tip",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = if (isHindi) "किसी भी फीचर में जाने के बाद '💡 सुझाव' चिप्स पर टैप करें। यह स्वचालित रूप से बेहतरीन प्रॉम्प्ट भर देगा और आप 1-क्लिक में रिजल्ट बना सकेंगे!" else "Tap on any '💡 Inspiration' suggestion chip inside any tool to instantly autofill high-converting prompts in 1-click!",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Saved Vault Quick Card
            if (savedItems.isNotEmpty()) {
                item(key = "card_saved_vault_preview") {
                    Card(
                        onClick = onNavigateToVault,
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                            .testTag("saved_creations_card")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = "Vault",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = if (isHindi) "सेव की गई रचनाएं (${savedItems.size})" else "Saved Vault (${savedItems.size})",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isHindi) "अपनी पुरानी कहानियां व प्रॉम्प्ट्स देखें" else "View your saved stories and prompts",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 11.sp
                                        ),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Text(
                                text = "➜",
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item(key = "home_bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
