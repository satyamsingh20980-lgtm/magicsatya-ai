package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = MinimalistPrimary,
    onPrimary = Color.White,
    primaryContainer = StoryTint,
    onPrimaryContainer = Color(0xFF001D35),
    secondary = MinimalistSecondary,
    onSecondary = Color.White,
    secondaryContainer = MinimalistSurfaceVariant,
    onSecondaryContainer = Color(0xFF0E1D2A),
    tertiary = MinimalistTertiary,
    onTertiary = Color.White,
    background = MinimalistBg,
    onBackground = TextPrimary,
    surface = MinimalistSurface,
    onSurface = TextPrimary,
    surfaceVariant = MinimalistSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = MinimalistBorder,
    outlineVariant = MinimalistBorderSubtle
)

private val DarkColorScheme = darkColorScheme(
    primary = MinimalistPrimaryLight,
    onPrimary = Color(0xFF003353),
    primaryContainer = MinimalistPrimaryDark,
    onPrimaryContainer = Color(0xFFCBE6FF),
    secondary = Color(0xFFB9C8DA),
    onSecondary = Color(0xFF233240),
    secondaryContainer = Color(0xFF3A4857),
    onSecondaryContainer = Color(0xFFD5E4F7),
    tertiary = Color(0xFF80D4E4),
    onTertiary = Color(0xFF00363D),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE1E2E8),
    surface = Color(0xFF1A1C1E),
    onSurface = Color(0xFFE1E2E8),
    surfaceVariant = Color(0xFF2E3135),
    onSurfaceVariant = Color(0xFFC4C7D0),
    outline = Color(0xFF43474E),
    outlineVariant = Color(0xFF2F333A)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We provide a distinct custom AI theme for MagicSatya AI by default
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
