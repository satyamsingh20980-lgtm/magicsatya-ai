package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MagicDatabase
import com.example.data.MagicItem
import com.example.engine.GeneratedImageData
import com.example.engine.GeneratedVideoData
import com.example.engine.ImageGenerationEngine
import com.example.engine.ImagePromptEngine
import com.example.engine.ImagePromptResult
import com.example.engine.StoryEngine
import com.example.engine.StoryResult
import com.example.engine.TtsManager
import com.example.engine.VideoGenerationEngine
import com.example.engine.VideoPromptEngine
import com.example.engine.VideoPromptResult
import com.example.engine.VoiceScriptEngine
import com.example.engine.VoiceScriptResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppLanguage {
    HINDI,
    ENGLISH
}

class MagicViewModel(application: Application) : AndroidViewModel(application) {

    private val db = MagicDatabase.getDatabase(application)
    private val dao = db.magicDao()
    val tts = TtsManager(application)

    // Saved items stream
    val savedItems: StateFlow<List<MagicItem>> = dao.getAllItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // App UI Language mode
    private val _currentLanguage = MutableStateFlow(AppLanguage.HINDI)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Loading states for AI generators
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Real Image Generation Loading States
    private val _isGeneratingImage = MutableStateFlow(false)
    val isGeneratingImage: StateFlow<Boolean> = _isGeneratingImage.asStateFlow()

    // Real Video Generation Loading States
    private val _isGeneratingVideo = MutableStateFlow(false)
    val isGeneratingVideo: StateFlow<Boolean> = _isGeneratingVideo.asStateFlow()

    private val _generatingSceneIndex = MutableStateFlow<Int?>(null)
    val generatingSceneIndex: StateFlow<Int?> = _generatingSceneIndex.asStateFlow()

    // Generated Results State
    private val _lastStoryResult = MutableStateFlow<StoryResult?>(null)
    val lastStoryResult: StateFlow<StoryResult?> = _lastStoryResult.asStateFlow()

    private val _lastImageResult = MutableStateFlow<ImagePromptResult?>(null)
    val lastImageResult: StateFlow<ImagePromptResult?> = _lastImageResult.asStateFlow()

    // Real Generated Image Artifacts
    private val _lastGeneratedImage = MutableStateFlow<GeneratedImageData?>(null)
    val lastGeneratedImage: StateFlow<GeneratedImageData?> = _lastGeneratedImage.asStateFlow()

    // Real Generated Video Artifacts
    private val _lastGeneratedVideo = MutableStateFlow<GeneratedVideoData?>(null)
    val lastGeneratedVideo: StateFlow<GeneratedVideoData?> = _lastGeneratedVideo.asStateFlow()

    // Map of Scene Index -> GeneratedImageData for Story Scenes
    private val _sceneImages = MutableStateFlow<Map<Int, GeneratedImageData>>(emptyMap())
    val sceneImages: StateFlow<Map<Int, GeneratedImageData>> = _sceneImages.asStateFlow()

    private val _lastVideoResult = MutableStateFlow<VideoPromptResult?>(null)
    val lastVideoResult: StateFlow<VideoPromptResult?> = _lastVideoResult.asStateFlow()

    private val _lastVoiceResult = MutableStateFlow<VoiceScriptResult?>(null)
    val lastVoiceResult: StateFlow<VoiceScriptResult?> = _lastVoiceResult.asStateFlow()

    // Status snackbar message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Friendly error message state
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.HINDI) AppLanguage.ENGLISH else AppLanguage.HINDI
    }

    fun showToast(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun clearError() {
        _errorMessage.value = null
    }

    // --- Generator Actions ---
    fun generateStory(
        topic: String,
        genre: String,
        tone: String,
        characterName: String,
        language: String,
        length: String,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            _errorMessage.value = null
            try {
                val result = withContext(Dispatchers.Default) {
                    StoryEngine.generateStoryAsync(topic, genre, tone, characterName, language, length)
                }
                _lastStoryResult.value = result
            } catch (e: Exception) {
                _errorMessage.value = if (_currentLanguage.value == AppLanguage.HINDI) 
                    "कहानी बनाने में त्रुटि हुई, कृपया पुनः प्रयास करें।" 
                else 
                    "Unable to generate story, using offline backup."
                // Safe offline fallback
                try {
                    val fallback = withContext(Dispatchers.Default) {
                        StoryEngine.generateStory(topic, genre, tone, characterName, language, length)
                    }
                    _lastStoryResult.value = fallback
                } catch (_: Exception) {}
            } finally {
                _isGenerating.value = false
                onComplete()
            }
        }
    }

    fun generateImagePrompt(
        userIdea: String,
        style: String,
        aspectRatio: String,
        lighting: String,
        camera: String,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            val result = withContext(Dispatchers.Default) {
                ImagePromptEngine.generatePrompt(userIdea, style, aspectRatio, lighting, camera)
            }
            _lastImageResult.value = result
            _isGenerating.value = false
            onComplete()
        }
    }

    fun generateVideoPrompt(
        sceneIdea: String,
        targetModel: String,
        cameraMotion: String,
        style: String,
        duration: String,
        fps: String,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            val result = withContext(Dispatchers.Default) {
                VideoPromptEngine.generateVideoPrompt(sceneIdea, targetModel, cameraMotion, style, duration, fps)
            }
            _lastVideoResult.value = result
            _isGenerating.value = false
            onComplete()
        }
    }

    fun generateVoiceScript(
        topic: String,
        category: String,
        tone: String,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            val result = withContext(Dispatchers.Default) {
                VoiceScriptEngine.generateScriptAsync(topic, category, tone)
            }
            _lastVoiceResult.value = result
            _isGenerating.value = false
            onComplete()
        }
    }

    // --- Real AI Image Generation Actions ---
    fun generateRealImageForPrompt(
        prompt: String,
        style: String = "Photorealistic 8K",
        aspectRatio: String = "1:1",
        onComplete: (GeneratedImageData) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGeneratingImage.value = true
            _errorMessage.value = null
            try {
                val app = getApplication<Application>()
                val result = ImageGenerationEngine.generateRealImage(
                    context = app,
                    prompt = prompt,
                    style = style,
                    aspectRatio = aspectRatio
                )
                _lastGeneratedImage.value = result
                onComplete(result)
            } catch (e: Exception) {
                _errorMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                    "छवि तैयार करने में समस्या आई, कृपया पुनः प्रयास करें।"
                else
                    "Failed to generate image, please try again."
            } finally {
                _isGeneratingImage.value = false
            }
        }
    }

    fun generateRealImageForScene(
        sceneIndex: Int,
        sceneHeader: String,
        scenePrompt: String,
        style: String = "Photorealistic 8K",
        aspectRatio: String = "16:9",
        onComplete: (GeneratedImageData) -> Unit = {}
    ) {
        viewModelScope.launch {
            _generatingSceneIndex.value = sceneIndex
            _errorMessage.value = null
            try {
                val app = getApplication<Application>()
                val result = ImageGenerationEngine.generateRealImage(
                    context = app,
                    prompt = scenePrompt,
                    style = style,
                    aspectRatio = aspectRatio,
                    sceneIndex = sceneIndex,
                    sceneHeader = sceneHeader
                )
                val currentMap = _sceneImages.value.toMutableMap()
                currentMap[sceneIndex] = result
                _sceneImages.value = currentMap
                onComplete(result)
            } catch (e: Exception) {
                _errorMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                    "दृश्य ${sceneIndex + 1} की छवि बनाने में समस्या आई।"
                else
                    "Failed to generate image for Scene ${sceneIndex + 1}."
            } finally {
                _generatingSceneIndex.value = null
            }
        }
    }

    fun downloadImageToGallery(imageData: GeneratedImageData) {
        viewModelScope.launch(Dispatchers.IO) {
            val bitmap = imageData.bitmap ?: return@launch
            val app = getApplication<Application>()
            val success = ImageGenerationEngine.saveImageToGallery(
                context = app,
                bitmap = bitmap,
                title = "MagicSatya_${imageData.sceneHeader ?: "Art"}"
            )
            withContext(Dispatchers.Main) {
                if (success) {
                    _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                        "📸 छवि सफलतापूर्वक गैलरी में सेव हो गई!"
                    else
                        "📸 Image saved to Pictures gallery!"
                } else {
                    _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                        "छवि सेव करने में त्रुटि हुई"
                    else
                        "Failed to save image"
                }
            }
        }
    }

    // --- Real AI Video Generation Actions ---
    fun generateRealVideoForPrompt(
        prompt: String,
        style: String = "Hyper-Realistic 4K Cinema",
        cameraMotion: String = "Cinematic Drone Orbit",
        modelName: String = "OpenAI Sora",
        durationSeconds: Int = 4,
        onComplete: (GeneratedVideoData) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isGeneratingVideo.value = true
            _errorMessage.value = null
            try {
                val app = getApplication<Application>()
                val result = VideoGenerationEngine.generateRealVideo(
                    context = app,
                    prompt = prompt,
                    style = style,
                    cameraMotion = cameraMotion,
                    modelName = modelName,
                    durationSeconds = durationSeconds
                )
                _lastGeneratedVideo.value = result
                onComplete(result)
            } catch (e: Exception) {
                _errorMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                    "वीडियो तैयार करने में समस्या आई, कृपया पुनः प्रयास करें।"
                else
                    "Failed to generate video, please try again."
            } finally {
                _isGeneratingVideo.value = false
            }
        }
    }

    fun downloadVideoToGallery(videoData: GeneratedVideoData) {
        viewModelScope.launch(Dispatchers.IO) {
            val path = videoData.localFilePath ?: return@launch
            val file = java.io.File(path)
            if (!file.exists()) return@launch
            val app = getApplication<Application>()
            val success = VideoGenerationEngine.saveVideoToGallery(
                context = app,
                videoFile = file,
                title = "MagicSatya_Video"
            )
            withContext(Dispatchers.Main) {
                if (success) {
                    _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                        "🎬 वीडियो सफलतापूर्वक Movies गैलरी में सेव हो गया!"
                    else
                        "🎬 Video saved to Movies gallery!"
                } else {
                    _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI)
                        "वीडियो सेव करने में त्रुटि हुई"
                    else
                        "Failed to save video"
                }
            }
        }
    }

    // --- Room Database Actions ---
    fun saveItem(
        category: String,
        title: String,
        hindiTitle: String,
        promptInput: String,
        generatedContent: String,
        secondaryContent: String = "",
        styleOrGenre: String = "",
        language: String = "Hindi"
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = MagicItem(
                category = category,
                title = title,
                hindiTitle = hindiTitle,
                promptInput = promptInput,
                generatedContent = generatedContent,
                secondaryContent = secondaryContent,
                styleOrGenre = styleOrGenre,
                language = language,
                timestamp = System.currentTimeMillis()
            )
            dao.insertItem(item)
            withContext(Dispatchers.Main) {
                _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI) "✅ वॉल्ट में सुरक्षित सेव हो गया!" else "✅ Saved to Vault!"
            }
        }
    }

    fun toggleFavorite(item: MagicItem) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.setFavorite(item.id, !item.isFavorite)
        }
    }

    fun deleteItem(item: MagicItem) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteItem(item)
            withContext(Dispatchers.Main) {
                _snackbarMessage.value = if (_currentLanguage.value == AppLanguage.HINDI) "आइटम हटा दिया गया" else "Item deleted"
            }
        }
    }

    // Audio TTS Helper
    fun speakText(text: String, isHindi: Boolean = true, speed: Float = 1.0f) {
        tts.speak(text, isHindi = isHindi, speed = speed)
    }

    fun stopSpeaking() {
        tts.stop()
    }

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
    }
}
