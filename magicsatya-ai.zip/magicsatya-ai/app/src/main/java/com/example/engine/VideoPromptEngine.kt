package com.example.engine

data class VideoPromptResult(
    val title: String,
    val masterPrompt: String,
    val cameraMovementPrompt: String,
    val motionAndPhysics: String,
    val lightingAndAtmosphere: String,
    val modelOptimization: String,
    val durationAndFps: String
)

object VideoPromptEngine {

    val aiVideoModels = listOf(
        "OpenAI Sora (अल्ट्रा स्मूथ मोशन)",
        "Runway Gen-3 Alpha (सिनेमैटिक रीयलिज्म)",
        "Kling AI (हाई डायनामिक मोशन)",
        "Luma Dream Machine (स्मूथ कैमरा पैन)",
        "Pika 2.0 (एनिमेशन और वीएफएक्स)"
    )

    val cameraMotions = listOf(
        "Cinematic Drone Orbit (चारों ओर घूमता ड्रोन शॉट)",
        "Dramatic Dolly-In Zoom (तेजी से पास आता ज़ूम)",
        "Slow Cinematic Pan Left-to-Right (धीमा पैन शॉट)",
        "First-Person POV Dynamic Walk (पहला व्यक्ति नजरिया)",
        "FPV High-Speed Flythrough (तेज स्पीड ड्रिफ्ट शॉट)",
        "Epic Low-Angle Crane Rise (नीचे से ऊपर उठता क्रेन शॉट)"
    )

    val videoStyles = listOf(
        "Hyper-Realistic 4K Cinema (4K असली फिल्म जैसा)",
        "3D CGI Unreal Engine 5 VFX (हॉलीवुड वीएफएक्स)",
        "Vintage 90s Film Grain (विंटेज रेट्रो स्टाइल)",
        "Anime Cinematic Motion (एनीमे मूवी स्टाइल)",
        "Hyperlapse Time-lapse Flow (टाइमलैप्स मोशन)"
    )

    val beginnerVideoIdeas = listOf(
        "एक सुनहरी चील जो बादलों के बीच से निकलकर हिमालय के ऊपर उड़ती है, 4K ड्रोन कैमरा।",
        "भविष्य की मुंबई में उड़ने वाली टैक्सियां जो रात की बारिश में नियॉन रोशनी बिखेर रही हैं।",
        "एक पुराना जादुई संदूक जो धीरे-धीरे खुलता है और उसमें से सोने की तितलियां बाहर उड़ती हैं।",
        "रेगिस्तान में रात को रेत का तूफान जो अचानक तारों की गैलेक्सी में बदल जाता है।",
        "रोबोट शेफ जो गरमा-गरम भारतीय जलेबियां बना रहा है, धीमी गति का हाई-स्पीड कैमरा।"
    )

    fun generateVideoPrompt(
        sceneIdea: String,
        targetModel: String,
        cameraMotion: String,
        style: String,
        duration: String = "5s",
        fps: String = "60 FPS Cinematic"
    ): VideoPromptResult {
        val concept = if (sceneIdea.isNotBlank()) sceneIdea.trim() else "Golden mystical lion walking gracefully through ethereal crystalline forest"

        val cameraDirective = when {
            cameraMotion.contains("Drone Orbit") -> "Camera orbits 360 degrees smoothly around the subject with seamless fluid motion, continuous parallax depth, stabilized high altitude drone perspective."
            cameraMotion.contains("Dolly-In") -> "Smooth continuous Dolly-in forward tracking shot advancing toward the focal point with progressive dramatic depth-of-field blur."
            cameraMotion.contains("Pan") -> "Slow horizontal cinematic Pan from left to right capturing rich environmental scale and environmental reflections."
            cameraMotion.contains("POV") -> "First-person perspective dynamic walking forward motion with subtle organic head-bob and realistic micro-movements."
            cameraMotion.contains("FPV") -> "FPV high-velocity aerodynamic flythrough weaving around obstacles with dynamic motion blur and tilt."
            else -> "Low-angle crane rising slowly upward unveiling the monumental landscape in panoramic vista."
        }

        val motionDirective = "Natural fluid physics, zero warping, consistent anatomy and temporal coherence, gentle atmospheric wind blowing hair and fabric, particles drifting gracefully in air."

        val lightingAtmosphere = "Volumetric god rays filtering through mist, 35mm film grain, anamorphic lens flare, realistic ambient occlusion, HDR color graded."

        val fullMasterPrompt = "$concept. $cameraDirective $motionDirective $lightingAtmosphere Style: $style, Ultra HD 4K, temporal consistency, smooth rendering."

        return VideoPromptResult(
            title = "Video AI: ${concept.take(30)}...",
            masterPrompt = fullMasterPrompt,
            cameraMovementPrompt = cameraDirective,
            motionAndPhysics = motionDirective,
            lightingAndAtmosphere = lightingAtmosphere,
            modelOptimization = "Optimized for $targetModel (Supports prompt adherence, keyframing, and motion brush).",
            durationAndFps = "$duration @ $fps"
        )
    }
}
