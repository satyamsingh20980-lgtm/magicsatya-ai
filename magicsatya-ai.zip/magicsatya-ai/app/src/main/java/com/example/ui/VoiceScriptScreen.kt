package com.example.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.VoiceScriptEngine
import com.example.ui.theme.MagicGold
import com.example.ui.theme.MagicPrimary
import com.example.ui.theme.VoiceScriptColor

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceScriptScreen(
    viewModel: MagicViewModel,
    onBackClick: () -> Unit
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isHindi = language == AppLanguage.HINDI
    val isGenerating by viewModel.isGenerating.collectAsState()
    val voiceResult by viewModel.lastVoiceResult.collectAsState()
    val isPlayingTts by viewModel.tts.isPlaying.collectAsState()

    var topic by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(VoiceScriptEngine.scriptCategories[0]) }
    var selectedTone by remember { mutableStateOf(VoiceScriptEngine.tones[0]) }
    var selectedScriptTab by remember { mutableIntStateOf(0) } // 0 = Hindi, 1 = Hinglish
    var speechSpeed by remember { mutableFloatStateOf(1.0f) }
    var isSaved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            MagicTopBar(
                title = if (isHindi) "वॉयस-ओवर स्क्रिप्ट" else "Voice-over Script Studio",
                subtitle = if (isHindi) "Reels, Shorts व पॉडकास्ट के लिए" else "For Reels, Shorts & Podcasts",
                onBackClick = onBackClick,
                currentLanguage = language,
                onLanguageToggle = { viewModel.toggleLanguage() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Info Pill
            item(key = "voice_header_info_pill") {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = VoiceScriptColor.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎙️",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isHindi) "वायरल वॉयस स्क्रिप्ट व टेलीप्रॉम्प्टर" else "Viral Script & Built-in Teleprompter",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = VoiceScriptColor
                            )
                            Text(
                                text = if (isHindi) "3 सेकंड का हुक + 3 मेन पॉइंट्स + कॉल टू एक्शन" else "Hook, body beats, call-to-action & native audio reader",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Input: Topic
            item(key = "voice_input_topic") {
                Column {
                    Text(
                        text = if (isHindi) "स्क्रिप्ट का विषय / टॉपिक (Video / Audio Topic)" else "Script Topic / Message",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        placeholder = {
                            Text(
                                text = if (isHindi) "उदा. 3 आदतें जो 30 दिनों में जिंदगी बदल देंगी, AI के 5 टॉप टूल्स..." else "e.g. 3 morning habits to 10x your productivity...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("voice_topic_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VoiceScriptColor,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // Beginner suggestions
            item(key = "voice_suggestions_section") {
                PromptSuggestionsSection(
                    title = "वायरल टॉपिक सुझाव (Viral Topics)",
                    hindiTitle = "1-क्लिक में चुनें",
                    suggestions = VoiceScriptEngine.beginnerTopics,
                    onSelectSuggestion = { topic = it }
                )
            }

            // Category Selector
            item(key = "voice_category_selector") {
                Column {
                    Text(
                        text = if (isHindi) "स्क्रिप्ट का प्रकार (Script Category)" else "Script Format / Platform",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoiceScriptEngine.scriptCategories.forEach { category ->
                            val isSelected = selectedCategory == category
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) VoiceScriptColor else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedCategory = category }
                                    .border(
                                        1.dp,
                                        if (isSelected) VoiceScriptColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = category,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Tone Selector
            item(key = "voice_tone_selector") {
                Column {
                    Text(
                        text = if (isHindi) "बोलने का अंदाज / टोन (Voice Tone)" else "Speaking Tone",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoiceScriptEngine.tones.forEach { tone ->
                            val isSelected = selectedTone == tone
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MagicPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedTone = tone }
                                    .border(
                                        1.dp,
                                        if (isSelected) MagicPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = tone,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Generate Button
            item(key = "voice_generate_button") {
                Button(
                    onClick = {
                        isSaved = false
                        viewModel.generateVoiceScript(
                            topic = topic,
                            category = selectedCategory,
                            tone = selectedTone
                        )
                    },
                    enabled = !isGenerating,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VoiceScriptColor
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("generate_voice_script_button")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            color = Color.Black,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isHindi) "स्क्रिप्ट लिखी जा रही है..." else "Crafting Voice Script...",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 15.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Generate",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "✨ वॉयस-ओवर स्क्रिप्ट बनाएं (Generate Script)" else "✨ Generate Voice Script",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Result Script Card with Teleprompter & TTS
            if (voiceResult != null) {
                item(key = "voice_result_card") {
                    val result = voiceResult!!
                    val activeScriptText = if (selectedScriptTab == 0) result.fullScriptHindi else result.fullScriptHinglish

                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(20.dp)
                            )
                            .testTag("voice_result_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Top Stats
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = VoiceScriptColor.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "🎙️ ${selectedCategory.split(" ")[0]}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = VoiceScriptColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = "⏱️ ~${result.estimatedDurationSeconds}s | ${result.wordCount} शब्द",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MagicGold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Script Language Tabs (Hindi Devnagari vs Hinglish)
                            TabRow(
                                selectedTabIndex = selectedScriptTab,
                                containerColor = MaterialTheme.colorScheme.surface,
                                indicator = { tabPositions ->
                                    SecondaryIndicator(
                                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedScriptTab]),
                                        color = VoiceScriptColor
                                    )
                                },
                                modifier = Modifier.clip(RoundedCornerShape(10.dp))
                            ) {
                                Tab(
                                    selected = selectedScriptTab == 0,
                                    onClick = { selectedScriptTab = 0 },
                                    text = {
                                        Text(
                                            text = "🇮🇳 शुद्ध हिंदी (Devnagari)",
                                            fontSize = 12.sp,
                                            fontWeight = if (selectedScriptTab == 0) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                )
                                Tab(
                                    selected = selectedScriptTab == 1,
                                    onClick = { selectedScriptTab = 1 },
                                    text = {
                                        Text(
                                            text = "🔤 Hinglish (रोमन हिंदी)",
                                            fontSize = 12.sp,
                                            fontWeight = if (selectedScriptTab == 1) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Full Script Body
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = activeScriptText,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 14.sp,
                                        lineHeight = 22.sp
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Speed Controls for TTS Voice Reader
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🔊 आवाज की गति (Speed):",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(0.8f, 1.0f, 1.2f, 1.5f).forEach { speed ->
                                        val isSelected = speechSpeed == speed
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSelected) MagicPrimary else MaterialTheme.colorScheme.surface,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable { speechSpeed = speed }
                                        ) {
                                            Text(
                                                text = "${speed}x",
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Toolbar
                            ResultActionToolbar(
                                contentToCopy = activeScriptText,
                                onPlayAudio = {
                                    if (isPlayingTts) {
                                        viewModel.stopSpeaking()
                                    } else {
                                        viewModel.speakText(
                                            text = activeScriptText,
                                            isHindi = selectedScriptTab == 0,
                                            speed = speechSpeed
                                        )
                                    }
                                },
                                isPlayingAudio = isPlayingTts,
                                isSaved = isSaved,
                                onSaveToVault = {
                                    viewModel.saveItem(
                                        category = "VOICE",
                                        title = result.title,
                                        hindiTitle = result.hindiTitle,
                                        promptInput = topic,
                                        generatedContent = result.fullScriptHindi,
                                        secondaryContent = result.fullScriptHinglish,
                                        styleOrGenre = selectedCategory,
                                        language = if (selectedScriptTab == 0) "Hindi" else "Hinglish"
                                    )
                                    isSaved = true
                                },
                                isHindi = isHindi
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
