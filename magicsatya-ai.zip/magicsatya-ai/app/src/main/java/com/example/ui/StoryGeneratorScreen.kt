package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.expandVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.StoryEngine
import com.example.ui.theme.MagicGold
import com.example.ui.theme.MagicPrimary
import com.example.ui.theme.MagicSecondary
import com.example.ui.theme.StoryColor

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StoryGeneratorScreen(
    viewModel: MagicViewModel,
    onBackClick: () -> Unit
) {
    val language by viewModel.currentLanguage.collectAsState()
    val isHindi = language == AppLanguage.HINDI
    val isGenerating by viewModel.isGenerating.collectAsState()
    val storyResult by viewModel.lastStoryResult.collectAsState()
    val isPlayingTts by viewModel.tts.isPlaying.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val sceneImages by viewModel.sceneImages.collectAsState()
    val generatingSceneIndex by viewModel.generatingSceneIndex.collectAsState()

    var topic by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf(StoryEngine.genres[0]) }
    var characterName by remember { mutableStateOf("") }
    var selectedTone by remember { mutableStateOf(StoryEngine.tones[0]) }
    var selectedLanguage by remember { mutableStateOf("Hindi") }
    var selectedLength by remember { mutableStateOf("60–90s (Voice-over)") }
    var isSaved by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            MagicTopBar(
                title = if (isHindi) "कहानी जनरेटर" else "Story Generator",
                subtitle = if (isHindi) "आकर्षक व प्रेरक कहानियां बनाएं" else "AI Story Studio with Audio",
                onBackClick = onBackClick,
                currentLanguage = language,
                onLanguageToggle = { viewModel.toggleLanguage() }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Info Pill
            item(key = "header_info_pill") {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = StoryColor.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📚",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isHindi) "अपनी मनपसंद कहानी तैयार करें" else "Create Customized Stories",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = StoryColor
                            )
                            Text(
                                text = if (isHindi) "विषय लिखें या नीचे दिए गए सुझावों में से चुनें" else "Type a theme or tap beginner suggestion chips below",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Input: Story Topic
            item(key = "input_story_topic") {
                Column {
                    Text(
                        text = if (isHindi) "कहानी का विषय / विचार (Story Topic)" else "Story Theme / Idea",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        placeholder = {
                            Text(
                                text = if (isHindi) "उदा. रामायण की अमर गाथा, महाभारत में गीता उपदेश, अंतरिक्ष का रहस्य..." else "e.g. Ramayana epic story, Mahabharata teachings, space voyage...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("story_topic_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StoryColor,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            // Quick Beginner Suggestions Chips
            item(key = "suggestions_section") {
                PromptSuggestionsSection(
                    title = "आइडिया सुझाव (Suggestions)",
                    hindiTitle = "1-टैप में चुनें",
                    suggestions = StoryEngine.beginnerPrompts,
                    onSelectSuggestion = { topic = it }
                )
            }

            // Input: Genre Picker
            item(key = "input_genre_picker") {
                Column {
                    Text(
                        text = if (isHindi) "शैली / जॉनर (Genre)" else "Story Genre",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StoryEngine.genres.forEach { genre ->
                            val isSelected = selectedGenre == genre
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) StoryColor else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedGenre = genre }
                                    .border(
                                        1.dp,
                                        if (isSelected) StoryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Text(
                                    text = genre,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    ),
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Input: Character Name
            item(key = "input_character_name") {
                Column {
                    Text(
                        text = if (isHindi) "मुख्य पात्र का नाम (Character Name - Optional)" else "Character Name (Optional)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = characterName,
                        onValueChange = { characterName = it },
                        placeholder = {
                            Text(
                                text = if (isHindi) "उदा. रोहन, मीरा, कबीर, रिया..." else "e.g. Rohan, Meera, Kabir, Riya...",
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("story_character_input"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StoryColor,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        singleLine = true
                    )
                }
            }

            // Language & Length Pickers Row
            item(key = "input_lang_len_pickers") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Language
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "भाषा (Language)" else "Language",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("Hindi", "Hinglish", "English").forEach { lang ->
                                val isSelected = selectedLanguage == lang
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MagicPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { selectedLanguage = lang }
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = when (lang) {
                                                "Hindi" -> "हिंदी"
                                                "Hinglish" -> "Hinglish"
                                                else -> "Eng"
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Length
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "लंबाई (Voice-Over Duration)" else "Voice-Over Duration",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("60–90s (Reel)", "2–3m (Short)", "4–5m (Long)").forEach { len ->
                                val isSelected = selectedLength.startsWith(len.take(4)) || (len.startsWith("60") && selectedLength.contains("60"))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) StoryColor else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { selectedLength = len }
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = len,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Error Display Banner (if any)
            if (errorMessage != null) {
                item(key = "error_banner") {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = errorMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearError() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Generate Story CTA Button
            item(key = "generate_cta_button") {
                Button(
                    onClick = {
                        isSaved = false
                        viewModel.generateStory(
                            topic = topic,
                            genre = selectedGenre,
                            tone = selectedTone,
                            characterName = characterName,
                            language = selectedLanguage,
                            length = selectedLength
                        )
                    },
                    enabled = !isGenerating,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StoryColor
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("generate_story_button")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isHindi) "कहानी बुनी जा रही है..." else "Weaving AI Story...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Generate",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "✨ जादुई कहानी बनाएं (Generate Story)" else "✨ Generate AI Story",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Generated Story Result Card
            if (storyResult != null) {
                item(key = "story_result_card_item") {
                    val result = storyResult!!
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(20.dp)
                            )
                            .testTag("story_result_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Top Badges
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StoryColor.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "📖 $selectedGenre",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = StoryColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = "⏱️ ${result.readingTimeMinutes}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = result.hindiTitle.ifBlank { result.title },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Story Scenes Display
                            StoryScenesDisplay(
                                fullStory = result.fullStory,
                                isHindi = isHindi,
                                sceneImages = sceneImages,
                                generatingSceneIndex = generatingSceneIndex,
                                onGenerateSceneImage = { index, header, prompt ->
                                    viewModel.generateRealImageForScene(
                                        sceneIndex = index,
                                        sceneHeader = header,
                                        scenePrompt = "$prompt, cinematic $selectedGenre film still, masterpiece 8k, photorealistic detailed lighting",
                                        style = selectedGenre,
                                        aspectRatio = "16:9"
                                    )
                                },
                                onDownloadImage = { img ->
                                    viewModel.downloadImageToGallery(img)
                                }
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Moral / Climax Box
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MagicGold.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = result.moralOrClimax,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    ),
                                    color = MagicGold,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Toolbar (TTS, Copy, Save, Share)
                            ResultActionToolbar(
                                contentToCopy = "${result.hindiTitle}\n\n${result.fullStory}\n\n${result.moralOrClimax}",
                                onPlayAudio = {
                                    if (isPlayingTts) {
                                        viewModel.stopSpeaking()
                                    } else {
                                        viewModel.speakText(
                                            text = result.fullStory,
                                            isHindi = selectedLanguage != "English"
                                        )
                                    }
                                },
                                isPlayingAudio = isPlayingTts,
                                isSaved = isSaved,
                                onSaveToVault = {
                                    viewModel.saveItem(
                                        category = "STORY",
                                        title = result.title,
                                        hindiTitle = result.hindiTitle,
                                        promptInput = topic,
                                        generatedContent = result.fullStory,
                                        secondaryContent = result.moralOrClimax,
                                        styleOrGenre = selectedGenre,
                                        language = selectedLanguage
                                    )
                                    isSaved = true
                                },
                                isHindi = isHindi
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun StoryScenesDisplay(
    fullStory: String,
    isHindi: Boolean,
    sceneImages: Map<Int, com.example.engine.GeneratedImageData> = emptyMap(),
    generatingSceneIndex: Int? = null,
    onGenerateSceneImage: ((Int, String, String) -> Unit)? = null,
    onDownloadImage: ((com.example.engine.GeneratedImageData) -> Unit)? = null
) {
    data class SceneBlock(val index: Int, val header: String, val body: String)

    val parsedScenes = remember(fullStory) {
        val sceneRegex = Regex("(?=(?:\\*\\*Scene|Scene)\\s*\\d+)", RegexOption.IGNORE_CASE)
        val rawBlocks = fullStory.split(sceneRegex).map { it.trim() }.filter { it.isNotBlank() }
        if (rawBlocks.size > 1) {
            rawBlocks.mapIndexed { index, block ->
                val lines = block.lines().map { it.trim() }.filter { it.isNotBlank() }
                val header = lines.firstOrNull()?.replace("**", "")?.trim() ?: "Scene ${index + 1}"
                val body = lines.drop(1).joinToString("\n\n").trim()
                SceneBlock(index, header, body)
            }
        } else {
            emptyList()
        }
    }

    val fallbackParagraphs = remember(fullStory, parsedScenes) {
        if (parsedScenes.isEmpty()) {
            fullStory.split("\n\n").map { it.trim() }.filter { it.isNotBlank() }
        } else {
            emptyList()
        }
    }

    if (parsedScenes.isNotEmpty()) {
        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            parsedScenes.forEach { scene ->
                val isThisSceneGenerating = generatingSceneIndex == scene.index
                val sceneImg = sceneImages[scene.index]

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StoryColor.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "🎬 ${scene.header}",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = StoryColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (scene.body.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = scene.body,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 14.sp,
                                    lineHeight = 22.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // If image already generated for this scene, show it!
                        if (sceneImg != null) {
                            RealGeneratedImageCard(
                                imageData = sceneImg,
                                isHindi = isHindi,
                                onDownload = { onDownloadImage?.invoke(sceneImg) },
                                onRegenerate = {
                                    onGenerateSceneImage?.invoke(scene.index, scene.header, scene.body)
                                }
                            )
                        } else if (onGenerateSceneImage != null) {
                            // Button to generate image for this scene
                            OutlinedButton(
                                onClick = {
                                    onGenerateSceneImage(scene.index, scene.header, scene.body)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = StoryColor
                                ),
                                enabled = !isThisSceneGenerating,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("generate_scene_${scene.index}_image_button")
                            ) {
                                if (isThisSceneGenerating) {
                                    CircularProgressIndicator(
                                        color = StoryColor,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isHindi) "दृश्य छवि जनरेट हो रही है..." else "Rendering Scene Image...",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Generate Scene Image",
                                        tint = StoryColor,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isHindi) "🎨 इस दृश्य की AI छवि बनाएं (${scene.header})" else "🎨 Generate Image for ${scene.header}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Fallback clean paragraph rendering
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            fallbackParagraphs.forEach { paragraph ->
                Text(
                    text = paragraph,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 14.sp,
                        lineHeight = 22.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
