package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MagicItem::class], version = 1, exportSchema = false)
abstract class MagicDatabase : RoomDatabase() {
    abstract fun magicDao(): MagicDao

    companion object {
        @Volatile
        private var INSTANCE: MagicDatabase? = null

        fun getDatabase(context: Context): MagicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MagicDatabase::class.java,
                    "magic_satya_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
