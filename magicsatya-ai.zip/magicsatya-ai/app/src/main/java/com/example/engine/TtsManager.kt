package com.example.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentText = MutableStateFlow("")
    val currentText: StateFlow<String> = _currentText.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    try {
                        val hindiLocale = Locale.forLanguageTag("hi-IN")
                        val availability = tts?.isLanguageAvailable(hindiLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                        if (availability >= TextToSpeech.LANG_AVAILABLE) {
                            tts?.language = hindiLocale
                        } else {
                            tts?.language = Locale.ENGLISH
                        }
                    } catch (_: Exception) {
                        tts?.language = Locale.ENGLISH
                    }
                }
            }

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                }
            })
        } catch (_: Exception) {
            tts = null
        }
    }

    fun speak(text: String, isHindi: Boolean = true, speed: Float = 1.0f) {
        if (text.isBlank()) return
        stop()
        _currentText.value = text

        try {
            val locale = if (isHindi) Locale.forLanguageTag("hi-IN") else Locale.ENGLISH
            tts?.language = locale
            tts?.setSpeechRate(speed)
            tts?.setPitch(1.0f)

            // Strip non-spoken markdown cues like [Pause] or [Tone]
            val cleanText = text.replace(Regex("\\[.*?\\]"), " ").trim()
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "MagicSatyaUtterance")
        } catch (_: Exception) {
            _isPlaying.value = false
        }
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
