package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Palette
val MinimalistPrimary = Color(0xFF00639B)        // Deep Oceanic Azure Blue
val MinimalistPrimaryLight = Color(0xFF4391C2)   // Soft Cyan Azure
val MinimalistPrimaryDark = Color(0xFF004975)    // Dark Navy Azure

val MinimalistSecondary = Color(0xFF51606F)      // Neutral Slate
val MinimalistSecondaryDark = Color(0xFF233240)

val MinimalistTertiary = Color(0xFF006874)       // Deep Teal
val MinimalistGold = Color(0xFFB45309)           // Warm Amber Gold Accent

// Clean Minimalism Backgrounds & Surfaces (Light)
val MinimalistBg = Color(0xFFF7F9FC)             // Clean Crisp Off-White Canvas
val MinimalistSurface = Color(0xFFFFFFFF)        // Pure White Card Surface
val MinimalistSurfaceVariant = Color(0xFFEFF1F8) // Soft Cool Gray-Blue Container
val MinimalistBorder = Color(0xFFE1E2E9)         // Subtle Crisp Card Border
val MinimalistBorderSubtle = Color(0xFFDDE3EA)

val TextPrimary = Color(0xFF1A1C1E)              // Deep High-Contrast Slate Black
val TextSecondary = Color(0xFF44474E)            // Refined Charcoal Gray
val TextMuted = Color(0xFF74777F)                // Slate Muted Gray

// Category Pastel Tints & Dark Accents (Clean Minimalism Style)
val StoryTint = Color(0xFFD3E4FF)                // Soft Sky Blue Container
val StoryColor = Color(0xFF00639B)               // Deep Sky Accent

val ImagePromptTint = Color(0xFFE8DEF8)          // Soft Lilac Container
val ImagePromptColor = Color(0xFF65558F)         // Refined Amethyst Purple

val VideoPromptTint = Color(0xFFFFDAD6)          // Soft Coral Rose Container
val VideoPromptColor = Color(0xFFB3261E)         // Deep Crimson Coral

val VoiceScriptTint = Color(0xFFD0F8D0)          // Soft Mint Sage Container
val VoiceScriptColor = Color(0xFF1E653F)         // Forest Jade Green

// Aliases for compatibility
val MagicPrimary = MinimalistPrimary
val MagicPrimaryLight = MinimalistPrimaryLight
val MagicPrimaryDark = MinimalistPrimaryDark
val MagicSecondary = MinimalistSecondary
val MagicSecondaryDark = MinimalistSecondaryDark
val MagicGold = MinimalistGold

