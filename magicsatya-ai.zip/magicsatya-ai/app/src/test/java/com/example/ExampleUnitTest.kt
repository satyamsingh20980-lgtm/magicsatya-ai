package com.example

import com.example.engine.ImagePromptEngine
import com.example.engine.StoryEngine
import com.example.engine.VideoPromptEngine
import com.example.engine.VoiceScriptEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testRamayanaStoryGeneration() {
        val result = StoryEngine.generateStory(
            topic = "रामायण पर 60 सेकंड की पूरी कहानी",
            genre = "Mythological & Epic",
            tone = "Inspiring",
            characterName = "",
            language = "Hindi",
            length = "Short Reel (60s)"
        )
        assertNotNull(result)
        assertTrue(result.fullStory.contains("श्री राम") || result.fullStory.contains("सीता"))
        assertTrue(result.fullStory.contains("हनुमान") || result.fullStory.contains("रावण"))
        assertTrue(result.wordCount > 50)
    }

    @Test
    fun testImagePromptGeneration() {
        val result = ImagePromptEngine.generatePrompt(
            userIdea = "प्रभु श्री राम धनुष के साथ",
            style = "Photorealistic 8K Cinematic",
            aspectRatio = "16:9",
            lighting = "Golden Hour Warm Sunlight",
            camera = "85mm f/1.4 Portrait Bokeh"
        )
        assertNotNull(result)
        assertTrue(result.masterPrompt.contains("8k resolution"))
        assertTrue(result.midjourneyFlags.contains("--ar 16:9"))
    }

    @Test
    fun testVideoPromptGeneration() {
        val result = VideoPromptEngine.generateVideoPrompt(
            sceneIdea = "हनुमान जी आकाश में उड़ते हुए",
            targetModel = "OpenAI Sora",
            cameraMotion = "Drone Orbit",
            style = "Hyper-Realistic Cinematic 8K",
            duration = "10s",
            fps = "60 FPS Smooth"
        )
        assertNotNull(result)
        assertTrue(result.masterPrompt.contains("orbits 360 degrees") || result.cameraMovementPrompt.contains("orbits 360 degrees"))
    }

    @Test
    fun testVoiceScriptGeneration() {
        val result = VoiceScriptEngine.generateScript(
            topic = "रामायण की सबसे बड़ी सीख",
            category = "Viral Short / Instagram Reel",
            tone = "High Energy"
        )
        assertNotNull(result)
        assertTrue(result.fullScriptHindi.contains("श्री राम") || result.fullScriptHindi.contains("रामायण"))
    }
}
